exports.handler = async event => {
    console.log('Received event %s', JSON.stringify(event));

    const response = {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Credentials": true
        },
        body: JSON.stringify({ message: "Hello World!" })
    };

    return response;
};