/*
* Filename: kms-interface.ts
* Path: 
* Created Date: Tuesday, Jan 21nd 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

import { BaseStackProps } from "./base-interface";

/**
* Interface for importing values into default-kms.ts nested stack file  
**/

export interface KmsStackProps extends BaseStackProps {
    description:string;
    alias:string;
}
