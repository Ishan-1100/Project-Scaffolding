/*
* Filename: lambda-layer-interface.ts
* Path: 
* Created Date: Tuesday, Jan 21nd 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Interface for importing values into lambda-layers-stack.ts nested stack file
**/
import {NestedStackProps,RemovalPolicy} from "aws-cdk-lib";
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Runtime } from "aws-cdk-lib/aws-lambda";


export interface SingleLayer {
    code:lambda.AssetCode,
    compatibleRuntimes:Runtime[]
    name:string,
    layerDescription:string,
    parameterStoreName:string  
}

export interface LayerConfig{
    codePath:string,
    name:string,
    layerDescription:string,
    parameterStoreName:string,
    type:string
}

export interface LambdaLayerStackProps extends NestedStackProps {
    removalPolicy:RemovalPolicy;
    layers: SingleLayer[]
}




