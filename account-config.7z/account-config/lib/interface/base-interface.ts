
/*
* Filename: base-interface.ts
* Path: 
* Created Date: Tuesday, Jan 21nd 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Interface for importing values into nested stack env-information-stack.ts file
**/
import { NestedStackProps } from "aws-cdk-lib"

export interface BaseStackProps extends NestedStackProps
{
    projectCode:string;
    appName:string;
}