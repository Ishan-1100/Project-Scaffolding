/*
* Filename: account-config-interface.ts
* Path: 
* Created Date: Tuesday, Jan 21nd 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Interface for importing values into parent stack account-config-stack.ts
**/

import { StackProps } from "aws-cdk-lib";

export interface AccountConfigStackProps extends StackProps {
    projectCode:string;
    appName:string;
}