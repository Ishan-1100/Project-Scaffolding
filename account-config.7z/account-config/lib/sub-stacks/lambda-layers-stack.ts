/*
* Filename: lambda-layers.ts
* Path: 
* Created Date: Tuesday, Jan 21nd 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Nested Stack for creating a lambda layer
**/

import { Construct } from 'constructs';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { NestedStack } from 'aws-cdk-lib';
import * as SSM from "aws-cdk-lib/aws-ssm";
import { LambdaLayerStackProps } from '../interface/lambda-layer-interface';

export class LambdaLayerStack extends NestedStack{
  
  constructor(scope: Construct, id: string, props: LambdaLayerStackProps ) {
    super(scope, id, props);
    
    //iterating over layers array of type SingleLayer interface
    //layerProps is the iterator used to fetch the code, name and compatibleRuntime for both the layers defined in layer-config.json
    //removalPolicy can be acccessed via props only
    for(let layerProps of props.layers){
      const layer =  new lambda.LayerVersion(this, `${layerProps.name}Layer`, {
        removalPolicy: props.removalPolicy,
        compatibleRuntimes : layerProps.compatibleRuntimes,
        layerVersionName:layerProps.name,
        code : layerProps.code,
      });

      new SSM.StringParameter(this, `${layerProps.name}Parameter`, {
        parameterName: layerProps.parameterStoreName,
        description: layerProps.layerDescription,
        stringValue: layer.layerVersionArn,
      });
    }
  }
}