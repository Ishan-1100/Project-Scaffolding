/*
* Filename: shared-services.ts
* Path: 
* Created Date: Tuesday, Jan 21nd 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Nested Stack for shared services //to be explained more
**/

import { NestedStack,NestedStackProps } from 'aws-cdk-lib';
import { Construct } from 'constructs';

export class SharedServiceStack extends NestedStack {
  constructor(scope: Construct, id: string, props?: NestedStackProps) {
    super(scope, id, props);

  }
}
