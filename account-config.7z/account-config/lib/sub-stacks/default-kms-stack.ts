/*
* Filename: default-kms-stack.ts
* Path: 
* Created Date: Tuesday, Jan 21nd 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Nested Stack creating a KMS key with policy attatched to allow basic kms actions 
**/
import { NestedStack,CfnOutput,Stack } from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as kms from 'aws-cdk-lib/aws-kms';
import {Construct} from 'constructs';
import { KmsStackProps } from '../interface/kms-interface';
import {getAccConfigResourceName} from '../../../shared/utils/utils'

export class DefaultKmsStack extends NestedStack {
  constructor(scope: Construct, id: string, props: KmsStackProps) {
    super(scope, id, props);
    const kmsKeyName = getAccConfigResourceName("kms",Stack.of(this).region,props.projectCode,props.appName); 
    const kmsKey = new kms.Key(this, 'KMSKey', {
      enableKeyRotation: true,
      alias: props.alias,
      description:props.description
    });

    const servicesStatement = new iam.PolicyStatement({
      actions: [
        'kms:Encrypt',
        'kms:Decrypt',
        'kms:ReEncrypt*',
        'kms:GenerateDataKey*'
      ],
      principals: [new iam.AccountRootPrincipal()],
      resources: ['*'],
      conditions: {
        StringEquals: {
          "kms:ViaService": [
            "secretsmanager.eu-west-1.amazonaws.com",
            "lambda.eu-west-1.amazonaws.com"
          ]
        }
      }
    });
    kmsKey.addToResourcePolicy(servicesStatement);

    new CfnOutput(this, `${kmsKeyName}-arn`, {
      value: kmsKey.keyArn,
      exportName:`${kmsKeyName}-arn`
    });
  }
}