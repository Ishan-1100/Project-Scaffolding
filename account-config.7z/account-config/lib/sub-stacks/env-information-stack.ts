/*
* Filename: env-information-stack.ts
* Path: 
* Created Date: Tuesday, Jan 21nd 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Nested Stack to fetch vpc, subnet ,security group, webAcl etc and the same values have been exported so that they can be used by other stacks.
**/
import { NestedStack,CfnOutput, CustomResource, Fn, Stack } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { Constants } from '../constants';
import { BaseStackProps } from '../interface/base-interface';

export class EnvInformationStack extends NestedStack {
  constructor(scope: Construct, id: string, props:BaseStackProps) {
    super(scope, id, props);

    /* this is the export Name published by a stack named envinformation which is run as prerequisite */
    const envResouce = new CustomResource(this, 'envResource', {
      serviceToken: Fn.importValue(Constants.PCP_LAMBDA_EXPORT_NAME),
      properties:{
        Region:Stack.of(this).region
      }
    });

    //
    const {projectCode,appName}  = props;
    const opPrefix = `${projectCode}-${appName}`;

    //L1 cdk constructs for exporting  values to other stacks
    new CfnOutput(this, 'hostedZoneName', {
      description: 'HostedZoneName',
      value: envResouce.getAtt(Constants.HOSTED_ZONE_ATT).toString(),
      exportName:`${opPrefix}-hostedZoneName`
    });

    new CfnOutput(this, 'vpcId', {
      description: 'vpcId',
      value: envResouce.getAtt(Constants.VPC_ID_ATT).toString(),
      exportName:`${opPrefix}-vpcId`
    });

    new CfnOutput(this, 'subnetAza', {
      description: 'subnetAza',
      value: envResouce.getAtt(Constants.SUBNET_AZ_A_ATT).toString(),
      exportName:`${opPrefix}-subnetAza`
    });

    new CfnOutput(this, 'subnetAzb', {
      description: 'subnetAzb',
      value: envResouce.getAtt(Constants.SUBNET_AZ_B_ATT).toString(),
      exportName:`${opPrefix}-subnetAzb`
    });

    new CfnOutput(this, 'pvtsubnetAza', {
      description: 'pvtsubnetAza',
      value: envResouce.getAtt(Constants.SUBNET_PVT_AZ_A_ATT).toString(),
      exportName:`${opPrefix}-pvtsubnetAza`
    });

    new CfnOutput(this, 'pvtsubnetAzb', {
      description: 'pvtsubnetAzb',
      value: envResouce.getAtt(Constants.SUBNET_PVT_AZ_B_ATT).toString(),
      exportName:`${opPrefix}-pvtsubnetAzb`
    });

    new CfnOutput(this, 'defaultSecurityGroupId', {
      description: 'defaultSecurityGroupId',
      value: envResouce.getAtt(Constants.DEFAULT_SG_ATT).toString(),
      exportName:`${opPrefix}-defaultSecurityGroupId`
    });

    new CfnOutput(this, 'globalWebACLWhitelistArn', {
      description: 'globalWebACLWhitelistArn',
      value: envResouce.getAtt(Constants.GLOBAL_WHITELIST_ARN_ATT).toString(),
      exportName:`${opPrefix}-globalWebACLWhitelistArn`
    });

    //exports for cidr blocks
    new CfnOutput(this, 'publicSubnetCidrAza', {
      description: 'publicSubnetCidrAza',
      value: envResouce.getAtt(Constants.PUBLIC_SUBNET_CIDR_AZ_A).toString(),
      exportName:`${opPrefix}-publicSubnetCidrAza`
    });

    new CfnOutput(this, 'publicSubnetCidrAzb', {
      description: 'publicSubnetCidrAzb',
      value: envResouce.getAtt(Constants.PUBLIC_SUBNET_CIDR_AZ_B).toString(),
      exportName:`${opPrefix}-publicSubnetCidrAzb`
    });

    new CfnOutput(this, 'privateSubnetCidrAza', {
      description: 'privateSubnetCidrAza',
      value: envResouce.getAtt(Constants.PRIVATE_SUBNET_CIDR_AZ_A).toString(),
      exportName:`${opPrefix}-privateSubnetCidrAza`
    });

    new CfnOutput(this, 'privateSubnetCidrAzb', {
      description: 'privateSubnetCidrAzb',
      value: envResouce.getAtt(Constants.PRIVATE_SUBNET_CIDR_AZ_B).toString(),
      exportName:`${opPrefix}-privateSubnetCidrAzb`
    });
  }
}
