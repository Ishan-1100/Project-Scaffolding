
/*
* Filename: constants.ts
* Path: 
* Created Date: Tuesday, Jan 21nd 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Constant class for storing constant value which will be used by nested stacks
**/
import { RemovalPolicy } from "aws-cdk-lib";
import { Runtime } from "aws-cdk-lib/aws-lambda";

type Runtimes = {
    [key:string]: Runtime[]
}

export class Constants
{
    //export Name published by a stack named envinformation which is run as prerequisite
    static readonly PCP_LAMBDA_EXPORT_NAME = "envinformation-LambdaArn";

    //constants related to env information stack
    static readonly HOSTED_ZONE_ATT = "hostedZoneDomain0public";
    static readonly VPC_ID_ATT = "vpcId";
    static readonly SUBNET_AZ_A_ATT = "subnetId0alocal_www";
    static readonly SUBNET_AZ_B_ATT = "subnetId0blocal_www";
    static readonly SUBNET_PVT_AZ_A_ATT = "subnetId0aprivate_lan";
    static readonly SUBNET_PVT_AZ_B_ATT = "subnetId0bprivate_lan";
    static readonly DEFAULT_SG_ATT = "DefaultSGId";
    static readonly GLOBAL_WHITELIST_ARN_ATT = "GlobalWebACLWhitelistArn";
    static readonly PUBLIC_SUBNET_CIDR_AZ_A = "subnetCidr0alocal_www";
    static readonly PUBLIC_SUBNET_CIDR_AZ_B = "subnetCidr0blocal_www";
    static readonly PRIVATE_SUBNET_CIDR_AZ_A = "subnetCidr0aprivate_lan";
    static readonly PRIVATE_SUBNET_CIDR_AZ_B = "subnetCidr0bprivate_lan";

    //constants related to KMS key
    static readonly KMS_KEY_DESCRIPTION = "default KMS Key";
    static readonly KMS_KEY_ALIAS = `alias/default`;

    //constants related to Jenkins Role
    static readonly JENKINS_ROLE_NAME = `cross-account-Jenkins-role`;
    static readonly JENKINS_ROLE_DESCRIPTION = "Role allows access to required resources on Central Jenkins account";

    //constants related to layers
    static readonly LAYER_REMOVAL_POLICY : RemovalPolicy = RemovalPolicy.DESTROY;

    static readonly COMPATIBLE_RUNTIMES :Runtimes = {
        "node":[
            Runtime.NODEJS_14_X,
            Runtime.NODEJS_16_X,
            Runtime.NODEJS_18_X
        ],
        "python":[
            Runtime.PYTHON_3_7,
            Runtime.PYTHON_3_8,
            Runtime.PYTHON_3_9
        ]
    }
};