#!/usr/bin/env node
/*
* Filename: account-config.ts
* Path: 
* Created Date: Tuesday, Jan 21nd 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Performs some checks and instantiation of the nested stacks
**/
import * as cdk from 'aws-cdk-lib';
import {Construct} from 'constructs';
import {DefaultKmsStack} from './sub-stacks/default-kms-stack';
import {EnvInformationStack} from './sub-stacks/env-information-stack';
import {LambdaLayerStack} from './sub-stacks/lambda-layers-stack';
import {SharedServiceStack} from './sub-stacks/shared-services-stack';
import {KmsStackProps} from './interface/kms-interface';
import {LambdaLayerStackProps, LayerConfig} from './interface/lambda-layer-interface';
import {exit} from "process";
import { AccountConfigStackProps } from './interface/account-config-interface';
import { Constants } from './constants';
import { readFileSync } from 'fs';
import { join } from 'path';
import { Code } from 'aws-cdk-lib/aws-lambda';
import { BaseStackProps } from './interface/base-interface';

/* Check all required parameters for KMS creation is initialized */ 
if (!Constants.KMS_KEY_DESCRIPTION || !Constants.KMS_KEY_ALIAS) {
    console.error("KMS properties missing");
    exit(1);
  }

/* Account Configuration Project Stack definition */
export class AccountConfigStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: AccountConfigStackProps) {
    super(scope, id, props);
    const {projectCode,appName} = props;  

    /* Basic Stack properties */
    const baseStackProps : BaseStackProps = {
      projectCode:projectCode,
      appName:appName
    };

    /* Interface Props values for KMS Stack */
    const kmsStackProps : KmsStackProps = {
      ...baseStackProps,
      description:Constants.KMS_KEY_DESCRIPTION,
      alias:Constants.KMS_KEY_ALIAS,
    }
    
    //Parse the layer config file
    const layerConfig = JSON.parse(readFileSync(join(__dirname,"../layers/layer-config.json")).toString('utf8')) as LayerConfig[];
    
    const layers = layerConfig.map(function(item){
      return {
        code:Code.fromAsset(join(__dirname, "../layers/",item.codePath)),
        compatibleRuntimes:Constants.COMPATIBLE_RUNTIMES[item.type],
        name:item.name,
        layerDescription:item.layerDescription,
        parameterStoreName:item.parameterStoreName  
      };
    });

    /* Interface Props values for lambda layer Stack */
    const lambdaLayerStackProps : LambdaLayerStackProps = {
      removalPolicy:Constants.LAYER_REMOVAL_POLICY,
      layers
    }


    /* KMS stack creation to create KMS key */
    const kmsStack = new DefaultKmsStack(this,"DefaultKMSStack",kmsStackProps);

    /* EnvStack is fetching existing config from a Lambda which is executed as a pre requisite */
    const EnvStack = new EnvInformationStack(this,"EnvInfoStack",baseStackProps);

    /* Lambda Layer stack is created to publish LogManagement library */
    const LambdaStack = new LambdaLayerStack(this,"LambdaLayerStack",lambdaLayerStackProps);

    /* Shared Services Stack for integrating log management/event management services */
    const SharedStack = new SharedServiceStack(this,"SharedServicesStack",{});
  }
}
