/*
* Filename: env-information.test
* Created Date: Tuesday, Jan 22nd 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Performs assertion test on envinformation substack
**/
import { App,Stack} from "aws-cdk-lib/core";
import { NestedStack } from "aws-cdk-lib";
import {Template} from "aws-cdk-lib/assertions";
import { EnvInformationStack } from '../lib/sub-stacks/env-information-stack';
import {TestConstants} from './testConstants';
//create app, stack and nested stack
describe("EnvInfoStack", () => {
  let app: App;
  app = new App();
  let stack: Stack;
  let nestedStack: NestedStack;
  const projectCode = TestConstants.projectCode;
  const appName = TestConstants.appName;

  //instantiating stack and app
  beforeEach(() => {
    stack = new Stack(app, "Stack", {});
    // let test file know which substack/nested stack to use for testing
    nestedStack =  new EnvInformationStack(stack, "NestedStack", {projectCode, appName});
  });

// testcases 
  test("creates ENV TEST", () => {
    const template = Template.fromStack(nestedStack);
    
      //template has multiple methods and hasOutput is one of them
      //we can not test against vpcId coz it does not get created in the cloudformtion template of nested envInformationStack
      template.hasOutput("vpcId", {
        //values are in token format so we are testing against the key names
        //it tests both Description key and its vpcId
        Description: "vpcId"
      });
      template.hasOutput("subnetAza", {
        Description: "subnetAza"
      });
      template.hasOutput("subnetAzb", {
        Description: "subnetAzb"
      });
      template.hasOutput("defaultSecurityGroupId", {
        Description: "defaultSecurityGroupId"
      });
      template.hasOutput("globalWebACLWhitelistArn", {
        Description: "globalWebACLWhitelistArn"
      });
      template.hasOutput("publicSubnetCidrAza", {
        Description: "publicSubnetCidrAza"
      });
      template.hasOutput("publicSubnetCidrAzb", {
        Description: "publicSubnetCidrAzb"
      });
      template.hasOutput("privateSubnetCidrAza", {
        Description: "privateSubnetCidrAza"
      });
      template.hasOutput("privateSubnetCidrAzb", {
        Description: "privateSubnetCidrAzb"
      });
  })
});
