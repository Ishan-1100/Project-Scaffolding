/*
 * Filename: default-kms.test
 * Created Date: Tuesday, Jan 22nd 2023, 11:12:59 pm
 * Author: ALS System Team
 *
 * Copyright (c) 2020 Airbus
 */

/**
 * Performs assertion test on default kms substack
 **/
import * as cdk from "aws-cdk-lib";
import { NestedStack } from "aws-cdk-lib";
import { DefaultKmsStack } from "../lib/sub-stacks/default-kms-stack";
import { Constants } from "../lib/constants";
import { Template } from "aws-cdk-lib/assertions";
import {TestConstants} from './testConstants';
describe("DefaultKmsStack", () => {
  let app: cdk.App;
  app = new cdk.App();
  let stack: cdk.Stack;
  let nestedStack: NestedStack;

  let description = Constants.KMS_KEY_DESCRIPTION;
  let alias = Constants.KMS_KEY_ALIAS;
  //props of kms-stack.ts
  const projectCode = TestConstants.projectCode;
  const appName = TestConstants.appName;

  beforeEach(() => {
    stack = new cdk.Stack(app, "TestStack", {});
    nestedStack = new DefaultKmsStack(stack, "DefaultKmsStack", {
      projectCode,
      appName,
      description,
      alias,
    });
  });

  // testcases 
  test(" KMS TEST", () => {
    // testing is performed against cloudformation template
    //referring template of Default KMS stack
    const template = Template.fromStack(nestedStack);

    //testing description
    template.hasResourceProperties("AWS::KMS::Key", {
      //it tests both Description key and its value vpcId
      Description: "default KMS Key",
    });

    //testing alias
    template.hasResourceProperties("AWS::KMS::Alias", {
      //it tests both AliasName key and its value vpcId
      AliasName: "alias/default",
    });
  });
});
