/*
* Filename: lambda-layer-event-publishing.test
* Path: 
* Created Date: Tuesday, Jan 22nd 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Performs assertion test on lambda-layer substack for Event Publishing 
**/
import { App, Stack } from "aws-cdk-lib/core";
import { NestedStack,RemovalPolicy } from "aws-cdk-lib";
import {Template} from "aws-cdk-lib/assertions";
import { LambdaLayerStackProps, LayerConfig } from '../lib/interface/lambda-layer-interface';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { LambdaLayerStack } from "../lib/sub-stacks/lambda-layers-stack";
import * as path from "path";

describe("Nested Stack IAM Role", () => {
  let app: App;
  app = new App();
  let stack: Stack;
  let nestedStack: NestedStack;
  beforeEach(() => {
    stack = new Stack(app, "Stack", {});
    nestedStack = new LambdaLayerStack(stack, "NestedStack", LambdaLayerStackProps);
  });

const layerConfig1: LayerConfig = {
      codePath:"../layers/node_modules/@als-lbd-layers/logger",
      name:"Event Publishing Layer",
      layerDescription:"Lambda layer for publishing events to event hub",
      parameterStoreName:"/layers/eventpublisher",
      type:"node"
}
const LambdaLayerStackProps: LambdaLayerStackProps = {
      removalPolicy: RemovalPolicy.DESTROY,
      layers: []
}
  test("creates a lmabda layer", () => {
      const layVer = new lambda.LayerVersion(nestedStack, "logManagementLayerLayertbd72225EC9", {
            code: lambda.Code.fromAsset(path.join(__dirname, '../layers/node_modules/@als-lbd-layers/evt-publisher-library')),
            removalPolicy: RemovalPolicy.DESTROY,
            compatibleRuntimes : [lambda.Runtime.NODEJS_14_X, lambda.Runtime.NODEJS_16_X, lambda.Runtime.NODEJS_18_X],
            layerVersionName:layerConfig1.name,
      });
      const tempLayer = Template.fromStack(nestedStack);
      tempLayer.hasResourceProperties("AWS::Lambda::LayerVersion", {
            LayerName: "Event Publishing Layer",     
      });
  });
});