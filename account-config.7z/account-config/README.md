## Account Configuration

## Purpose 
The purpose of the document is to define the account configuration stack to be referred by projects. This stack needs to be deployed once at the start of the project.

## Overview
Stacks are implemented in nested form, a single stack named AccountConfigParentStack will create five nested stacks and these nested stacks are in turn creating the required services over AWS.

Code is available in following Github Repo: https://github.airbus.corp/airline-support-platform/project-scaffolding.git

## Prerequisites
As pre-requisite following steps have to be completed:
1. Deploy the Lambda provided by PCP to fetch the existing AWS account-related necessary configs
	- Access the below GitHub repo: airline-support-platform/Pattern-EnvironementInformation: This pattern allows you to deploy a Custom Resource Backed Lambda to extract the Project information from your AWS account (airbus.corp)
	- As per the ReadMe, deploy it via the link below: https://eu-west-1.console.aws.amazon.com/cloudformation/home?region=eu-west-1#/stacks/create/review?templateURL=https://s3-ew1-c81d-envinfo.s3-eu-west-1.amazonaws.com/envinfo.yaml&stackName=envinformation
	- Parameters that need to be provided as part of this are:
		- vpcId (String) which contains your unique default VPC.
		- subnet1Id (String) which contains the first Subnet ID in which the function will run.
		- subnet2Id (String) which contains the second Subnet ID in which the function will run.  

2. Create an IAM role for Jenkins having administrative access to deploy resources over AWS account using CloudFormation templates via Jenkins job.

3. Required packages/tools for using AWS CDK:
	-	Install Node and npm from https://nodejs.org/en/download/
	-	Install AWS client and CDK client into your local 
	-	To install the AWS client:  https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html
	-	To install CDK client: (npm install -g aws-cdk)

## Steps to Deploy Account Config

Steps to Deploy account config stack in project scaffolding:
1. Allow Jenkins steps to have input params for aspire code, environment and app name.
2. Checkout GitHub code:
	- ```$git clone https://github.airbus.corp/airline-support-platform/project-scaffolding.git```
3. Go to the project scaffolding directory:
	- ```$cd project-scaffolding```
4. Go to the Account config directory:
	- ```$cd account-config```
5. Install the dependencies: 
	- create a .npmrc file with the below contents:
	```
	registry = https://artifactory.2b82.aws.cloud.airbus.corp/artifactory/api/npm/r-airbus-npm-virtual/
	@als-c81d-aws-cdk:registry=https://artifactory.2b82.aws.cloud.airbus.corp/artifactory/api/npm/r-c81d-alsplatform-npm-local/
	@als-lbd-layers:registry=https://artifactory.2b82.aws.cloud.airbus.corp/artifactory/api/npm/r-c81d-alsplatform-npm-local/
	cafile=../../../cacerts-airbus.pem
	always-auth = true
	auth = “auth as generated for given email”
	```
	- run the installation command line : ```$npm install```
	- If needed, follow the official link if it's the first time: https://confluence.airbus.corp/display/2DUD/Use+a+npm+repository

6.	Install the dependencies for lambda layers:
```
$cd layers
$npm install
```
7.	Go to account-config folder and verify AWS account accessibility:
```
$cd ../
$cdk bootstrap 
$cdk synth
```
8.	To verify the test cases:
```
$npm run test
```

9.	Deploy the CDK stack for account config:
```
$cdk deploy –all -c  projectCode=params.aspireCode  -c appName=params.appName --outputs-file ./env-output.json
```
## Below is the description of stacks created in this project repository 

### AccountConfigParentStack:  It instantiates all the nested stacks and creates them as resources on cloudformation on AWS console.

### Substacks
1.	**EnvInformationStack**: 	This stack uses lambda function (deployed as a prerequisite) to extract values such as VPC , subnet, security goup, WebAcl.
3.	**LambdaLayerStack**: 		Creates the lambda layer which can be used with other Lambda functions expecting to implement logger and event publishing capabilities.
4.	**KMSStack**: 				Creates a default KMS key to be used within the project.
5.	**SharedServiceStack**: 	Stacks related to event hub onboarding and log management onboarding to be added

This cdk app project repository contains folders with bin, lib and layers :
- **bin**: cdk app for Account Config Stack is initiated.
- **lib**: This folder contains the project Stack account config definition. Lib consists of sub-folders: sub-stacks and interface.
	- Sub-stacks:	All the sub stacks are defined within individual files in this folder.
	- Interface: 	This folder consists of individual files defining interfaces for each sub stack.
- **layers**: It contains two files layer-config.json and package.json and is used to manage layers to be added to the account.
	- layer-config.json: It contains a JSON array of object which has configuration corresponding to each lambda layer to be created. Here is the meaning of properties of the object
		- codePath: Path to the layer code within the layers folder
		- name: Name to be given to the Lambda layer
		- layerDescription: Description to be given to the Lambda layer
		- parameterStoreName: name of the parameter store where ARN of the created Lambda layer will be stored. Lambda functions meaning to use a layer can refer to this parameter store to access the ARN.
		- type: type of the layer. e.g node, python etc. This property is used to refer to right run times that are defined in the Constants class.
	- package.json: The package.json file is used to manage the npm packages that will be added as layers. Currently two packages related to log and event publishing are provided.

# Utilizing this account config stack in projects:

Based on the requirement, a project can include the required sub stacks within the project.

For using a specific sub stack, changes are required in the respective interface file.

Predefined sets on inputs like aspire code (project code), project name (app name), environment are to be defined in the cdk.json file as context variables.

These can also be passed with -c option of the cdk deploy command, e.g

```sh
cdk deploy -c projectCode=c81d -c appName=als-demo
```
