/*
* Filename: cognito-stack.ts
* Path: 
* Created Date: Tuesday, Jan 31st 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Nested Stack creating a Cognito Stack with UserPool
**/
import { UserPool,UserPoolProps,UserPoolIdentityProviderOneLogin,UserPoolClient} from '@als-c81d-aws-cdk/als-cognito';
import * as cognito from 'aws-cdk-lib/aws-cognito'
import { Fn, NestedStack } from 'aws-cdk-lib';
import {Construct} from 'constructs';
import {CognitoStackProps} from '../interface/cognito-interface'

export class CognitoStack extends NestedStack {
  public readonly userPool: cognito.IUserPool;
  public readonly userPoolDomain: cognito.CfnUserPoolDomain;
  public readonly userPoolClient: cognito.IUserPoolClient;
  // public readonly oneLoginIdp: cognito.IUserPoolIdentityProvider;

  constructor(scope: Construct, id: string, props: CognitoStackProps) {
    super(scope, id, props);
      const {projectCode,appName,environment,oneLoginMetaDataUrl,customAttributes,oneLoginAttributesMapping} = props;
      const userPoolProps:UserPoolProps = {
        projectCode,
        accountAliasNumber:"",
        nameSuffix:appName,
        stage:environment,
        oneLoginMetaDataUrl,
        customAttributes
      };
      const userPool =   new UserPool(this, id, userPoolProps);

       // Add UserPoolDomain
      const domainProps: cognito.CfnUserPoolDomainProps = {
        userPoolId: userPool.userPoolId,
        domain:`${appName}-${environment}`
      };
      const userPoolDomain = new cognito.CfnUserPoolDomain(this, `${id}UserPoolDomain`, domainProps);

       // Add OneLogin IdP if metadataUrl is provided
       if (oneLoginMetaDataUrl) {
        const idpProps = {
          userPool: userPool,
          metaDataUrl: oneLoginMetaDataUrl,
          attributesMapping: oneLoginAttributesMapping
        };
  
        const oneLoginIdp = new UserPoolIdentityProviderOneLogin(this, `${id}UserPoolIdentityProviderOneLogin`, idpProps);
        userPool.registerIdentityProvider(oneLoginIdp);
      }

      //add a client with localhost redirect if the environment is dev
      if(environment === "dev"){
        const userPoolClientPropsLocalHost = {
          nameSuffix: `${appName}-localhost`,
          projectCode: projectCode,
          userPool: userPool,
          stage: environment,
          callbackUrLs: ['https://localhost:3000', 'http://localhost:3000', 'https://oauth.pstmn.io/v1/browser-callback'],
          logoutUrLs: ['https://localhost:3000', 'http://localhost:3000', 'https://oauth.pstmn.io/v1/browser-callback'],
          forceCognitoIdentity: true,
          supportedIdentityProviders:props.oneLoginMetaDataUrl ? ['airbus-onelogin'] : []
        };
  
        new UserPoolClient(this, 'WipsUserPoolClientLocalhost1', userPoolClientPropsLocalHost);
      }

      const hostedZoneName = Fn.importValue(`${projectCode}-${appName}-hostedZoneName`);
      const callBackUrlCloudfront = `https://cloudfront-${environment}-${appName}.${hostedZoneName}`;
      let callBackUrlAlias = `https://${appName}-${environment}.airbus-v.com`;
      if(environment === "prod"){
        callBackUrlAlias = `${appName}.airbus.com`;
      }

      //add client for cloudfront access
      const userPoolClientProps = {
        nameSuffix: appName,
        projectCode: projectCode,
        userPool: userPool,
        stage: environment,
        callbackUrLs: [callBackUrlCloudfront+"/parseauth", callBackUrlAlias+"/parseauth"],//will be added later during cloudfront creation
        logoutUrLs: [callBackUrlCloudfront,callBackUrlAlias],//will be added later during cloudfront creation
        forceCognitoIdentity: false,
        supportedIdentityProviders:props.oneLoginMetaDataUrl ? ['airbus-onelogin'] : []
      };
  
      this.userPoolClient = new UserPoolClient(this, 'WipsUserPoolClient1', userPoolClientProps);

      this.userPool = userPool;
      this.userPoolDomain = userPoolDomain;

  }
}