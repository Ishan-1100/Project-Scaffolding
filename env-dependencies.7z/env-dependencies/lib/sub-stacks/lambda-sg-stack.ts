/*
* Filename: lambda-sg-stack.ts
* Path: 
* Created Date: Tuesday, Jan 31st 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Nested Stack creating a Lambda SecurityGroup (EgressRule) within the NetworkingVpc
**/

import {NestedStack, Stack, Fn,CfnOutput} from 'aws-cdk-lib';
import { Peer, Port, SecurityGroup, Vpc } from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
import { getResourceName } from '../../../shared/utils/utils';
import { BaseStackProps } from '../interface/base-interface';

export class LambdaSgStack extends NestedStack {
  constructor(scope: Construct, id: string, props: BaseStackProps) {
    super(scope, id, props);
    const {projectCode,appName,environment}  = props;
    const opPrefix = `${projectCode}-${appName}`;

    const networkingVpc = Vpc.fromVpcAttributes(this, 'NetworkingVpc', {
      availabilityZones: ['eu-west-1a', 'eu-west-1b'],
      publicSubnetIds: [
        Fn.importValue(`${opPrefix}-subnetAza`),
        Fn.importValue(`${opPrefix}-subnetAzb`)
      ],
      vpcId: Fn.importValue(`${opPrefix}-vpcId`),
    });
    const sg = new SecurityGroup(this, 'LambdaSG', {
      vpc: networkingVpc,
      allowAllOutbound:false,
      securityGroupName: getResourceName("sg",Stack.of(this).region,environment,projectCode,appName,"lambda-sg")
    });

    sg.addEgressRule(Peer.anyIpv4(),Port.tcp(443),"Allow HTTPS");
    sg.addEgressRule(Peer.ipv4(Fn.importValue(`${opPrefix}-privateSubnetCidrAza`)),Port.allTcp(),"Allow HTTPS");
    sg.addEgressRule(Peer.ipv4(Fn.importValue(`${opPrefix}-privateSubnetCidrAzb`)),Port.allTcp(),"Allow HTTPS");
    sg.addEgressRule(Peer.ipv4(Fn.importValue(`${opPrefix}-publicSubnetCidrAza`)),Port.allTcp(),"Allow HTTPS");
    sg.addEgressRule(Peer.ipv4(Fn.importValue(`${opPrefix}-publicSubnetCidrAzb`)),Port.allTcp(),"Allow HTTPS");

    new CfnOutput(this, 'lambdaSgId', {
      description: 'lambdaSgId',
      value: sg.securityGroupId,
      exportName:`${environment}-${projectCode}-${appName}-lambdaSecurityGroupId`
    });
  }
}
