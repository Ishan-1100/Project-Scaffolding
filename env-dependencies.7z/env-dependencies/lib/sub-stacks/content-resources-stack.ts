/*
* Filename: content-resources-stack.ts
* Path:
* Created Date: Tuesday, Jan 31st 2023, 11:12:59 pm
* Author: ALS System Team
*
* Copyright (c) 2020 Airbus
*/
import * as cdk from 'aws-cdk-lib'
import { CfnOutput, NestedStack, Stack } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import {getResourceName} from '../../../shared/utils/utils'
import { Bucket, BlockPublicAccess, BucketEncryption } from 'aws-cdk-lib/aws-s3';
import { Key } from "aws-cdk-lib/aws-kms";
import { S3StackProps } from '../interface/s3-interface';

export class S3Stack extends NestedStack {
    constructor(scope: Construct, id: string, props: S3StackProps) {
      super(scope, id, props);
      const {projectCode,appName,environment}  = props;
      const ikey = Key.fromKeyArn(this, "kmsKey", props.kmskeyArn);
      const s3bucket = new Bucket(this, 'contentResourcesS3', {
        bucketName: getResourceName("s3",Stack.of(this).region,environment,projectCode,appName,"content-resources"),
        removalPolicy: cdk.RemovalPolicy.DESTROY,
        autoDeleteObjects: true,
        blockPublicAccess: BlockPublicAccess.BLOCK_ALL,
        publicReadAccess:false,
        encryption: BucketEncryption.KMS,
        encryptionKey: ikey,
        versioned:true
      });

      new CfnOutput(this, 'contentResourcesS3Name', {
        description: 'contentResourcesS3Name',
        value: s3bucket.bucketName,
        exportName:`${environment}-${projectCode}-${appName}-contentResourcesS3Name`
      });

      new CfnOutput(this, 'contentResourcesS3Arn', {
        description: 'contentResourcesS3Arn',
        value: s3bucket.bucketArn,
        exportName:`${environment}-${projectCode}-${appName}-contentResourcesS3Arn`
      });
    }
  }