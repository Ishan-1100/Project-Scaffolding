import * as cdk from "aws-cdk-lib";
import { Stack, aws_events as events } from "aws-cdk-lib";
import { Key } from "aws-cdk-lib/aws-kms";
import { Role} from "aws-cdk-lib/aws-iam";
import * as backup from "aws-cdk-lib/aws-backup";
import { Construct } from "constructs";
import { BackupStackProps } from "../interface/backup-interface";
import { Constants } from "../constants";
import { getResourceName } from '../../../shared/utils/utils'

export class AWSBackupStack extends cdk.NestedStack {
    constructor(scope: Construct, id: string, props:BackupStackProps) {
        super(scope, id, props);

        const vaultName = getResourceName("backupVault",Stack.of(this).region,props.environment,props.projectCode,props.appName); 
        const backupPlanNameDaily = getResourceName("backupPlan",Stack.of(this).region,props.environment,props.projectCode,props.appName,"Daily"); 
        const backupRuleNameDaily = getResourceName("backupRule",Stack.of(this).region,props.environment,props.projectCode,props.appName,"Daily"); 
        const backupSelectionNameDaily = getResourceName("backupSelection",Stack.of(this).region,props.environment,props.projectCode,props.appName,"Daily"); 
        const backupPlanNameWeekly = getResourceName("backupPlan",Stack.of(this).region,props.environment,props.projectCode,props.appName,"Weekly"); 
        const backupRuleNameWeekly = getResourceName("backupRule",Stack.of(this).region,props.environment,props.projectCode,props.appName,"Weekly"); 
        const backupSelectionNameWeekly = getResourceName("backupSelection",Stack.of(this).region,props.environment,props.projectCode,props.appName,"Weekly"); 
        const backupRoleArn = `arn:aws:iam::${process.env.CDK_DEFAULT_ACCOUNT}:role/service-role/${Constants.BACKUPROLE}`
        const ikey = Key.fromKeyArn(this, "kmsKey", props.kmskeyArn);
        const role = Role.fromRoleArn(this, 'backupRole', backupRoleArn);
        const backupVault = new backup.BackupVault(this, "BackupVault", {
          backupVaultName:vaultName,
          encryptionKey:ikey
        })
        backupVault.grant(role, 'backup:StartBackupJob');

        const ibackup = backup.BackupVault.fromBackupVaultName(this, "IBackupVault", backupVault.backupVaultName)

        const backupPlanDaily = new backup.BackupPlan(this, "DailyBackupPlan", {
          backupVault:ibackup,
          backupPlanName:backupPlanNameDaily,
        })
        backupPlanDaily.addRule(new backup.BackupPlanRule({
          ruleName:backupRuleNameDaily,
          enableContinuousBackup: true,
          completionWindow: Constants.BACKUPCOMPLETIONWINDOW,
          startWindow: Constants.BACKUPSTARTWINDOW,
          deleteAfter: cdk.Duration.days(31),
          // Only cron expressions are supported
          scheduleExpression: events.Schedule.cron({
            minute: '0',
            hour: '2',
          }),
           copyActions: [{
            destinationBackupVault: backupVault,
            moveToColdStorageAfter: cdk.Duration.days(30),
            deleteAfter: cdk.Duration.days(120),
          }]
        }));;

        backupPlanDaily.addSelection('Selection', {
          resources: [
            backup.BackupResource.fromTag('Daily-Backup', 'true'), // Backup Resources based on tag
            ],
          backupSelectionName:backupSelectionNameDaily,
          role:role,
          allowRestores:true
        })

        /* Weekly Backup Plan to take Backup of resources at 8pm UTC on Friday */
        const backupPlanWeekly = new backup.BackupPlan(this, "WeeklyBackupPlan", {
          backupVault:ibackup,
          backupPlanName:backupPlanNameWeekly,
        })
        backupPlanWeekly.addRule(new backup.BackupPlanRule({
          ruleName:backupRuleNameWeekly,
          enableContinuousBackup: true,
          completionWindow: Constants.BACKUPCOMPLETIONWINDOW,
          startWindow: Constants.BACKUPSTARTWINDOW,
          deleteAfter: cdk.Duration.days(31),
          // Only cron expressions are supported
          scheduleExpression: events.Schedule.cron({
            minute: '0',
            hour: '20',
            weekDay:'FRI'
          }),
           copyActions: [{
            destinationBackupVault: backupVault,
            moveToColdStorageAfter: cdk.Duration.days(30),
            deleteAfter: cdk.Duration.days(120),
          }]
        }));;

        backupPlanWeekly.addSelection('Selection', {
          resources: [
            backup.BackupResource.fromTag('Weekly-Backup', 'true'), // Backup Resources based on tag
            ],
          backupSelectionName:backupSelectionNameWeekly,
          role:role,
          allowRestores:true
        })
  }
}
