/*
* Filename: env-kms-stack.ts
* Path: 
* Created Date: Tuesday, Jan 31st 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Nested Stack creating a CMK KMS key with policy attatched to allow basic kms actions 
**/
import { NestedStack,CfnOutput,Stack } from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as kms from 'aws-cdk-lib/aws-kms';
import {Construct} from 'constructs';
import { KmsStackProps } from '../interface/env-kms-interface';
import {getResourceName} from '../../../shared/utils/utils'

export class EnvKmsStack extends NestedStack {
  kmsKey:kms.Key;
  constructor(scope: Construct, id: string, props: KmsStackProps) {
    super(scope, id, props);
    const kmsKeyName = getResourceName("kms",Stack.of(this).region,props.environment,props.projectCode,props.appName); 
    this.kmsKey = new kms.Key(this, 'KMSKey', {
    enableKeyRotation: true,
    alias: kmsKeyName,
    description:props.description
  });

    const servicesStatement = new iam.PolicyStatement({
      actions: [
        'kms:Encrypt',
        'kms:Decrypt',
        'kms:ReEncrypt*',
        'kms:GenerateDataKey*'
      ],
      principals: [new iam.AccountRootPrincipal()],
      resources: ['*'],
      conditions: {
        StringEquals: {
          "kms:ViaService": [
            "secretsmanager.eu-west-1.amazonaws.com",
            "lambda.eu-west-1.amazonaws.com"
          ]
        }
      }
    });
    this.kmsKey.addToResourcePolicy(servicesStatement);

    new CfnOutput(this, `${kmsKeyName}-arn`, {
      value: this.kmsKey.keyArn,
      exportName:`${kmsKeyName}-arn`
    });
  }
}