import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { Stack, Fn} from "aws-cdk-lib";
import { Secret } from "aws-cdk-lib/aws-secretsmanager";
import * as rds from 'aws-cdk-lib/aws-rds';
import { Credentials, ParameterGroup } from "aws-cdk-lib/aws-rds";
import { Vpc ,Subnet} from "aws-cdk-lib/aws-ec2";
import { RdsStackProps } from '../interface/db-stack-interface';
import {getResourceName} from '../../../shared/utils/utils'
import { Constants } from '../constants';

export class RdsStack extends cdk.NestedStack {
  public readonly response: string;
  cluster:rds.ServerlessCluster;
  constructor(scope: Construct, id: string, props: RdsStackProps) {
    super(scope, id, props); 
    const {projectCode,appName,environment}  = props;
    const opPrefix = `${projectCode}-${appName}`;
    const vpc = Vpc.fromVpcAttributes(this, 'ImportVpc', {
        availabilityZones: ['eu-west-1a', 'eu-west-1b'],
        privateSubnetIds: [
          Fn.importValue(`${opPrefix}-pvtsubnetAzb`),
          Fn.importValue(`${opPrefix}-pvtsubnetAzb`)
        ],
        vpcId: props.vpcConfig.vpcId,
      });
    const subnet1 = Subnet.fromSubnetId(
        this,
        "subnet1",
        Fn.importValue(`${opPrefix}-pvtsubnetAza`)
    );
    const subnet2 = Subnet.fromSubnetId(
        this,
        "subnet2",
        Fn.importValue(`${opPrefix}-pvtsubnetAzb`)
    );

    const stack = Stack.of(this);
    //----------Database-------------
    const clusterIdentifier = getResourceName("database",Stack.of(this).region,props.environment,props.projectCode,props.appName);
    // Creating secret credentials
    const databaseCredentialsSecret = new Secret(this, "DBMasterSecretCredentials1", {
      secretName: getResourceName("credentials",Stack.of(this).region,environment,projectCode,appName,"db-creds"),
      description: "Secret arn for db aurora mysql ",
      generateSecretString: {
        secretStringTemplate: JSON.stringify({ username: "mysqladmin" }),
        generateStringKey: "password",
        passwordLength: 30,
        excludeCharacters: '"@/\\',
        excludePunctuation: true,
        includeSpace: false,
      },
    });
    /** Version "8.0.mysql_aurora.3.01.0". */
    const dbEngine = rds.DatabaseClusterEngine.auroraMysql({ version: Constants.AURORAENGINEVERSION })
    
    //Creating rds aurora serverless mysql
    this.cluster = new rds.ServerlessCluster(this, "dbCluster", {
      defaultDatabaseName: "AuroraMysql",
      clusterIdentifier:clusterIdentifier,
      engine: Constants.AURORAENGINE,
      parameterGroup: ParameterGroup.fromParameterGroupName(this, 'ParameterGroup', Constants.MYSQLPARAMETERGROUP),
      credentials: Credentials.fromSecret(databaseCredentialsSecret),
      vpc,
      vpcSubnets: {
        subnets: [subnet1, subnet2],
      },
      enableDataApi: true, // Optional - will be automatically set if you call grantDataApiAccess(),
      scaling: {
        minCapacity: rds.AuroraCapacityUnit.ACU_1,
        maxCapacity: rds.AuroraCapacityUnit.ACU_2,
      }
      //securityGroups
    });

    //  export SecretArn for cross-stack reference
    new cdk.CfnOutput(this, 'SecretArnOutput', {
      value: databaseCredentialsSecret.secretArn,
      description: 'The arn value of secret arn',
      exportName: `${props.environment}-AuroraServerSecretARN`
    });
    //  export Database arn for cross-stack reference
    new cdk.CfnOutput(this, 'DatabaseResourceArnOutput', {
      value: this.cluster.clusterArn,
      description: 'The arn value of Aurora Serverless cluster',
      exportName: `${props.environment}-AuroraServerARN`,
    });
  }
}