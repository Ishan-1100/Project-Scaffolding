#!/usr/bin/env node

/*
* Filename: env-dependency-stack.ts
* Path: 
* Created Date: Tuesday, Jan 31st 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Performs some checks and instantiation of the nested stacks
**/

import { Construct } from 'constructs';
import { Stack, CfnOutput, Tags, Fn } from 'aws-cdk-lib';
import {EnvKmsStack} from './sub-stacks/env-kms-stack';
import {KmsStackProps} from './interface/env-kms-interface';
import {CognitoStack} from './sub-stacks/cognito-stack';
import {CognitoStackProps} from './interface/cognito-interface';
import {LambdaSgStack} from './sub-stacks/lambda-sg-stack'
import {exit} from "process";
import { Constants } from './constants';
import {EnvDependenciesStackProps} from './interface/env-dependencies-interface'
import {S3Stack} from './sub-stacks/content-resources-stack'
import {S3StackProps} from './interface/s3-interface'
import { BaseStackProps } from './interface/base-interface';
import {RdsStack} from './sub-stacks/db-stack'
import { RdsStackProps } from './interface/db-stack-interface';
import {BackupStackProps} from './interface/backup-interface';
import {AWSBackupStack} from './sub-stacks/backup-stack';

/* Check all required parameters for KMS creation is initialized */
if (!Constants.KMS_KEY_DESCRIPTION) {
    console.error("KMS properties missing");
    exit(1);
  }

/* Check all required parameters for Cognito creation is initialized */
if (!Constants.ONE_LOGIN_METADATA_URLS) {
  console.error("Cognito properties missing");
  exit(1);
}

/* Check all required parameters for Lambda Edge is initialized */
if (!Constants.EDGE_RUNTIME || !Constants.capaList) {
    console.error("Lambda Edge properties missing");
    exit(1);
  }

/* Check all required parameters for RDS Aurora is initialized */
if (!Constants.AURORAENGINE || !Constants.AURORAENGINEVERSION || !Constants.MYSQLPARAMETERGROUP) {
  console.error("RDS Aurora properties missing");
  exit(1);
}
/* Check all required parameters for AWS Backup is initialized */
if (!Constants.BACKUPROLE) {
  console.error("IAM Role for creating Backup is missing");
  exit(1);
}

/* Check the time difference between start window and completion window must be 1h */
if (Constants.BACKUPCOMPLETIONWINDOW.toHours() - Constants.BACKUPSTARTWINDOW.toHours() < 1) {
  console.error("Backup completion window must be at least 60 minutes greater than backup start window");
  exit(1);
}


/* Environment Dependency Project Stack definition */
export class EnvDependenciesStack extends Stack {
  authenticationCognitoStack:CognitoStack;
  envKmsStack:EnvKmsStack;
  auroraStack:RdsStack;
  constructor(scope: Construct, id: string, props: EnvDependenciesStackProps) {
    super(scope, id, props);
    const {projectCode,appName,environment} = props;  

    const baseStackProps : BaseStackProps = {
      projectCode,
      appName,
      environment
    };

    /* Fetching VPC Details */
    const opPrefix = `${projectCode}-${appName}`;
    const vpcId = Fn.importValue(`${opPrefix}-vpcId`);
    
    /* Interface Props values for CMK KMS Stack */
    const kmsStackProps : KmsStackProps = {
      ...baseStackProps,
      description:Constants.KMS_KEY_DESCRIPTION,
    };

    /* Interface Props Values for Cognito Stack */
    const cognitoStackProps : CognitoStackProps = {
      ...baseStackProps,
      oneLoginMetaDataUrl:Constants.ONE_LOGIN_METADATA_URLS[environment]
    };

    /* Interface Props Value for Aurora Serverless Stack */
    const rdsStackProps : RdsStackProps = {
      ...baseStackProps,
      vpcConfig:{vpcId:vpcId}
    }

    /* KMS stack creation to create CMK KMS key */
    this.envKmsStack = new EnvKmsStack(this,"CMKKMSStack",kmsStackProps);

    /* Cognito stack creation for authentication */
    this.authenticationCognitoStack = new CognitoStack(this,"CognitoStack",cognitoStackProps);

    /* Lambda Security group Stack creation */
    const lambdaSgStack = new LambdaSgStack(this, "LambdaSgStack",baseStackProps);

    /* Interface Props Value for Content-Resources S3 stack */
    const s3StackProps : S3StackProps = {
      ...baseStackProps,
      kmskeyArn:this.envKmsStack.kmsKey.keyArn
    }

    /* S3 stack creation for storing content resources */
    const s3Stack = new S3Stack(this, "ContentResourcesS3",s3StackProps);
    /* Tag S3 Stack for automated AWS backup */
    Tags.of(s3Stack).add('Weekly-Backup', 'true');

    /* RDS Aurora serverless Stack creation */
    this.auroraStack = new RdsStack(this, "AuroraServerless", rdsStackProps);
    /* Tag RDS Stack for automated AWS backup */
    Tags.of(this.auroraStack).add('Weekly-Backup', 'true');

    /* Interface props value for Backup Stack */
    const backupStackProps : BackupStackProps = {
      ...baseStackProps,
      kmskeyArn:this.envKmsStack.kmsKey.keyArn,
      backupRole:Constants.BACKUPROLE
    };

    /* Backup Stack */
    const backupStack = new AWSBackupStack(this, "AWSBkpStack", backupStackProps);

    /* Export values for the Cognito UserPool Stack */
    new CfnOutput(this, "userPoolId", {
      value: this.authenticationCognitoStack.userPool.userPoolId,
      exportName: `${projectCode}-${appName}-${environment}-UserPoolId`,
      description: "UserPool ID"
    });
    new CfnOutput(this, "userPoolClientId", {
      value: this.authenticationCognitoStack.userPoolClient.userPoolClientId,
      exportName: `${projectCode}-${appName}-${environment}-UserPoolClientId`,
      description: "UserPool Client ID"
    });
    new CfnOutput(this, "userPoolDomain", {
      value: this.authenticationCognitoStack.userPoolDomain.domain,
      exportName: `${projectCode}-${appName}-${environment}-userPoolDomain`,
      description: "UserPool Domain Name"
    });
  }
}

