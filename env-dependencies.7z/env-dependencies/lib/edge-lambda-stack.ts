/*
* Filename: edge-lambda-stack.ts
* Path: 
* Created Date: Tuesday, Jan 31st 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Stack creating a Lambda Edge to authorize UserPool
**/
import { Stack } from "aws-cdk-lib";
import { Construct } from "constructs";
import { Synth } from "../../shared/config/synth";
import * as ssm from 'aws-cdk-lib/aws-ssm'; 
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as path from 'path';
import * as fs from 'fs';
import { getResourceName } from "../../shared/utils/utils";
import { EdgeFunction } from "../edge-deployer";
import { Constants } from "./constants";
import { ConfigFromDisk, EnvOutput } from "./interface/edge-interface";
import { LambdaEdgeStackProps } from "./interface/env-dependencies-interface";

const envOutput = JSON.parse(fs.readFileSync(path.join(__dirname,"../env-output.json")).toString('utf8')) as EnvOutput;
const firstKey = Object.keys(envOutput)[0];
const {userPoolId,userPoolClientId,userPoolDomain} = envOutput[firstKey];
const config = JSON.parse(fs.readFileSync(path.join(__dirname,"../edge-config.json")).toString('utf8')) as ConfigFromDisk;

export class EdgeLambdaStack extends Stack {
  constructor(scope: Construct, id: string, props: LambdaEdgeStackProps) {
    super(scope, id, {
      ...props
    });

    const cognitoDomain = `${userPoolDomain}.auth.${Stack.of(this).region}.amazoncognito.com`;

    config.clientId = userPoolClientId;
    config.capaList = Constants.capaList;
    config.cognitoAuthDomain = cognitoDomain;
    config.userPoolId = userPoolId;

    let data = JSON.stringify(config);

    fs.writeFileSync(path.join(__dirname,'..','./lambda@edge','code','parse-auth','configuration.json'), data);
    fs.writeFileSync(path.join(__dirname,'..','./lambda@edge','code','check-auth','configuration.json'), data);
    fs.writeFileSync(path.join(__dirname,'..','./lambda@edge','code','refresh-auth','configuration.json'), data);
    fs.writeFileSync(path.join(__dirname,'..','./lambda@edge','code','sign-out','configuration.json'), data);
    fs.writeFileSync(path.join(__dirname,'..','./lambda@edge','code','api-insert-header','configuration.json'), data);
    fs.writeFileSync(path.join(__dirname,'..','./lambda@edge','code','http-headers','configuration.json'), JSON.stringify(config.httpHeaders));

    const stackId = `${props.environment}-cfn-ue1-${props.projectCode}-${props.appName}-edge`;

    const parseAuth = new EdgeFunction(this,"parseauth",{
      runtime: Constants.EDGE_RUNTIME,
      handler: 'bundle.handler',
      functionName: `${getResourceName("lambda",Stack.of(this).region,props.environment,props.projectCode,props.appName,"parseauth")}`,
      code: lambda.Code.fromAsset(path.join(__dirname,'..','./lambda@edge','code','parse-auth')),
      stackId,
      synth:Synth
    });

    new ssm.StringParameter(this, "ssmparseauth", {
      parameterName: `${getResourceName("ssm",Stack.of(this).region,props.environment,props.projectCode,props.appName,"parseauth")}`,
      stringValue:parseAuth.currentVersion.edgeArn,
    });

    const checkAuth = new EdgeFunction(this,"checkAuth",{
      runtime: Constants.EDGE_RUNTIME,
      handler: 'bundle.handler',
      functionName:`${getResourceName("lambda",Stack.of(this).region,props.environment,props.projectCode,props.appName,"checkauth")}`,
      code: lambda.Code.fromAsset(path.join(__dirname,'..','./lambda@edge','code','check-auth')),
      stackId,
      synth:Synth
    });

    new ssm.StringParameter(this, "ssmcheckAuth", {
      parameterName: `${getResourceName("ssm",Stack.of(this).region,props.environment,props.projectCode,props.appName,"checkauth")}`,
      stringValue:checkAuth.currentVersion.edgeArn,
    });

    const refreshAuth = new EdgeFunction(this,"refreshAuth",{
      runtime: Constants.EDGE_RUNTIME,
      handler: 'bundle.handler',
      functionName:`${getResourceName("lambda",Stack.of(this).region,props.environment,props.projectCode,props.appName,"refreshauth")}`,
      code: lambda.Code.fromAsset(path.join(__dirname,'..','./lambda@edge','code','refresh-auth')),
      stackId,
      synth:Synth
    });

    new ssm.StringParameter(this, "ssmrefreshAuth", {
      parameterName: `${getResourceName("ssm",Stack.of(this).region,props.environment,props.projectCode,props.appName,"refreshauth")}`,
      stringValue:refreshAuth.currentVersion.edgeArn,
    });

    const signOut = new EdgeFunction(this,"signOut",{
      runtime: Constants.EDGE_RUNTIME,
      handler: 'bundle.handler',
      functionName:`${getResourceName("lambda",Stack.of(this).region,props.environment,props.projectCode,props.appName,"signout")}`,
      code: lambda.Code.fromAsset(path.join(__dirname,'..','./lambda@edge','code','sign-out')),
      stackId,
      synth:Synth
    });

    new ssm.StringParameter(this, "ssmsignOut", {
      parameterName: `${getResourceName("ssm",Stack.of(this).region,props.environment,props.projectCode,props.appName,"signout")}`,
      stringValue:signOut.currentVersion.edgeArn,
    });

    const apiInsertHeader = new EdgeFunction(this,"apiInsertHeader",{
      runtime: Constants.EDGE_RUNTIME,
      handler: 'bundle.handler',
      functionName:`${getResourceName("lambda",Stack.of(this).region,props.environment,props.projectCode,props.appName,"api-inserthd")}`,
      code: lambda.Code.fromAsset(path.join(__dirname,'..','./lambda@edge','code','api-insert-header')),
      stackId,
      synth:Synth
    });

    new ssm.StringParameter(this, "ssmapiInsertHeader", {
      parameterName: `${getResourceName("ssm",Stack.of(this).region,props.environment,props.projectCode,props.appName,"api-inserthd")}`,
      stringValue:apiInsertHeader.currentVersion.edgeArn,
    });

    const httpHeaders = new EdgeFunction(this,"httpHeaders",{
      runtime: Constants.EDGE_RUNTIME,
      handler: 'bundle.handler',
      functionName:`${getResourceName("lambda",Stack.of(this).region,props.environment,props.projectCode,props.appName,"httpheaders")}`,
      code: lambda.Code.fromAsset(path.join(__dirname,'..','./lambda@edge','code','http-headers')),
      stackId,
      synth:Synth
    });

    new ssm.StringParameter(this, "ssmhttpHeaders", {
      parameterName: `${getResourceName("ssm",Stack.of(this).region,props.environment,props.projectCode,props.appName,"httpheaders")}`,
      stringValue:httpHeaders.currentVersion.edgeArn,
    });    
  }
}