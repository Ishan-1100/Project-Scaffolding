/*
* Filename: constants.ts
* Path: 
* Created Date: Tuesday, Jan 31st 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

import { Runtime } from "aws-cdk-lib/aws-lambda";
import {CustomResourceProviderRuntime} from "aws-cdk-lib";
import * as cdk from "aws-cdk-lib";
import * as rds from 'aws-cdk-lib/aws-rds';

/**
* Constant class for storing constant value which will be used by nested stacks
**/

interface KeyValue {
    [key: string]: string;
}
export class Constants{
    //constants related to KMS key
    static readonly KMS_KEY_DESCRIPTION = "CMK KMS Key";

    //one login metadata urls
    static readonly ONE_LOGIN_METADATA_URLS:  KeyValue = {
        "dev":"",
        "int":"",
        "val":"",
        "prod":""
    };

    //lambda edge run time
    static readonly EDGE_RUNTIME: Runtime = Runtime.NODEJS_16_X;

    //Capalist as required by the project
    static readonly capaList:string[] = []; 

    //CustomResourceProviderRuntime as required in EdgeFunction
    static readonly CustomResourceProviderRuntime:CustomResourceProviderRuntime = CustomResourceProviderRuntime.NODEJS_16_X

    //Backup Role for AWS Backup
    static readonly BACKUPROLE = "AWSBackupDefaultServiceRole";
    static readonly BACKUPCOMPLETIONWINDOW = cdk.Duration.minutes(120);
    static readonly BACKUPSTARTWINDOW = cdk.Duration.minutes(60);

    //Aurora Parameters
    static readonly AURORAENGINE = rds.DatabaseClusterEngine.AURORA_MYSQL;
    static readonly AURORAENGINEVERSION = rds.AuroraMysqlEngineVersion.VER_3_01_0;
    static readonly MYSQLPARAMETERGROUP = "default.aurora-mysql5.7"
};