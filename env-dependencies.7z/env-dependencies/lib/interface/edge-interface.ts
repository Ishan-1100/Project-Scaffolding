/*
* Filename:edge-interface.ts
* Path: 
* Created Date: Tuesday, Jan 31st 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Interface for importing values into env-kms-stasck.ts nested stack file  
**/
import { BaseStackProps } from "./base-interface";

export interface EdgeStackProps extends BaseStackProps {
    userPoolId:string;
    userPoolClientId:string;
    cognitoDomain:string;
}

export interface CookieSettings {
    idToken: string;
    accessToken: string;
    refreshToken: string;
    nonce: string;
}

export interface KeyValue {
    [key: string]: string;
  }
  
export interface ConfigFromDisk {
    userPoolId: string;
    clientId: string;
    oauthScopes: string[];
    cognitoAuthDomain: string;
    redirectPathSignIn: string;
    redirectPathSignOut: string;
    redirectPathAuthRefresh: string;
    cookieSettings: CookieSettings;
    httpHeaders: KeyValue;
    capaList:string[];
}

export interface EnvOutput{
    [key: string]:KeyValue
}