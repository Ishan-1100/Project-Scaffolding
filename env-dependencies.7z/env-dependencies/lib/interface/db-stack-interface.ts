/*
* Filename:db-stack-interface.ts
* Path: 
* Created Date: Tuesday, Mar 13th 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Interface for importing values into db-stack.ts nested stack file  
**/
import { BaseStackProps } from "./base-interface"
export interface RdsStackProps extends BaseStackProps {
    vpcConfig: {
      vpcId: string
    }
  }