/*
* Filename: env-dependencies-interface.ts
* Path: 
* Created Date: Tuesday, Jan 31st 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Interface for importing values into parent stack env-dependency-stack.ts
**/

import { StackProps } from "aws-cdk-lib";

export interface EnvDependenciesStackProps extends StackProps {
    projectCode:string;
    appName:string;
    environment:string;
}

export interface LambdaEdgeStackProps extends EnvDependenciesStackProps {
    userPoolId:string;
    userPoolClientId:string;
    userPoolDomain:string;
}