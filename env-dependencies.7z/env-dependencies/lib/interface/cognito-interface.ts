/*
* Filename: cognito-interface.ts
* Path: 
* Created Date: Tuesday, Jan 31st 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

import { AttributeMappingDict } from "@als-c81d-aws-cdk/als-cognito";
import { ICustomAttribute } from "aws-cdk-lib/aws-cognito";
import { BaseStackProps } from "./base-interface";

/**
* Interface for importing values into cognito-stack.ts nested stack file
**/
export interface CognitoStackProps extends BaseStackProps{
  oneLoginMetaDataUrl?:string;
  customAttributes?: { [key: string]: ICustomAttribute },
  oneLoginAttributesMapping?: AttributeMappingDict,
}



