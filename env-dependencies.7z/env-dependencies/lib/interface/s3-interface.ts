/*
* Filename: s3-interface.ts
* Path: 
* Created Date: Tuesday, Mar 10 2023, 11:12:59 am
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Interface for importing values into backup-stasck.ts nested stack file  
**/
import { BaseStackProps } from "./base-interface";

export interface S3StackProps extends BaseStackProps {
    kmskeyArn:string;
}
