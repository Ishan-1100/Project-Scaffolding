/*
* Filename: env-kms-interface.ts
* Path: 
* Created Date: Tuesday, Jan 31st 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Interface for importing values into env-kms-stasck.ts nested stack file  
**/
import { BaseStackProps } from "./base-interface";

export interface KmsStackProps extends BaseStackProps {
    description:string;
}