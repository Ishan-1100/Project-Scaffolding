/*
* Filename: backup-interface.ts
* Path: 
* Created Date: Tuesday, Mar 10 2023, 11:12:59 am
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Interface for importing values into backup-stasck.ts nested stack file  
**/
import { BaseStackProps } from "./base-interface";

export interface BackupStackProps extends BaseStackProps {
    kmskeyArn:string;
    backupRole:string;
}
