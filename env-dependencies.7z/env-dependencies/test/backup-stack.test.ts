/*
 * Filename: backup.test
 * Created Date: Tuesday, Mar 16th 2023, 11:12:59 pm
 * Author: ALS System Team
 *
 * Copyright (c) 2020 Airbus
 */

/**
 * Performs assertion test on AWS backup substack
 **/
 import * as cdk from "aws-cdk-lib";
 import { NestedStack } from "aws-cdk-lib";
 import { AWSBackupStack } from "../lib/sub-stacks/backup-stack";
 import { BackupStackProps } from "../lib/interface/backup-interface";
 import { Key } from "aws-cdk-lib/aws-kms";
 import { Constants } from "../lib/constants";
 import { Template } from "aws-cdk-lib/assertions";
 import * as backup from "aws-cdk-lib/aws-backup";
 import {getResourceName} from '../../shared/utils/utils'; 
 import {TestConstants} from './testConstants';
 
 let process : {
     env: {
       [key: string]: string
     }
   }
 
 describe("EnvKmsStack1", () => {
   let app: cdk.App;
   app = new cdk.App();
   let stack: cdk.Stack;
   let nestedStack: NestedStack;
 
   const projectCode = TestConstants.projectCode;
   const appName = TestConstants.appName;
   const environment = TestConstants.environment;
   const region = TestConstants.region;
   const vaultName = getResourceName("backupVault",region,environment,projectCode,appName);
   const kmskeyArn = "arn:aws:kms:eu-west-1:585903036745:key/776033db-e62b-4788-91f3-a8fd15cc15e4";
   //props of backup-stack.ts
   const backupStackProps: BackupStackProps = {
    kmskeyArn: kmskeyArn,
    backupRole:Constants.BACKUPROLE,
    environment: environment,
    projectCode: projectCode,
    appName: appName
    }
 
   beforeEach(() => {
     app = new cdk.App();
     stack = new cdk.Stack(app, "TestStack", {});
     nestedStack = new AWSBackupStack(stack, "TestEnvKmsStack", backupStackProps);
   });
 
   // testcases 
   test("Backup Test", () => {
    const ikey = Key.fromKeyArn(nestedStack, "TestKmsKey", kmskeyArn);
    const backupVault = new backup.BackupVault(nestedStack, "TestBackupVault", {
        backupVaultName:vaultName,
        encryptionKey:ikey
    });
     // testing is performed against cloudformation template
     //referring template of AWS Backup stack
     const template = Template.fromStack(nestedStack);
 
     //testing description
     template.hasResourceProperties("AWS::Backup::BackupVault", {
       //it tests Backup vault name
       BackupVaultName: "dev-bvlt-ew1-c81d-als-test"
     });
   });
 });