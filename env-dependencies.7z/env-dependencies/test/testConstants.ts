export class TestConstants{
    //constants related to test cases
    static readonly projectCode = "c81d";
    static readonly environment = "dev";
    static readonly appName = "als-test";
    static readonly region = "eu-west-1";
}
