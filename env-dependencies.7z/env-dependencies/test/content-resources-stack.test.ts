/*
 * Filename: content-resources-stack.test
 * Created Date: Tuesday, Feb 22nd 2023, 11:12:59 pm
 * Author: ALS System Team
 *
 * Copyright (c) 2020 Airbus
 */

/**
 * Performs assertion test on content resources substack
 **/
import { App, Stack, NestedStack } from 'aws-cdk-lib';
import { BaseStackProps } from '../lib/interface/base-interface';
import { Template } from 'aws-cdk-lib/assertions';
import { S3Stack } from '../lib/sub-stacks/content-resources-stack';
import { Constants } from '../lib/constants';
import { TestConstants } from './testConstants';

describe('S3Stack', () => {
  let app: App;
  let stack: Stack;
  let nestedStack: NestedStack;

  beforeAll(() => {
    app = new App();
    stack = new Stack(app, 'TestStack');
    const projectCode = TestConstants.projectCode;
    const appName = TestConstants.appName;
    const environment = TestConstants.environment;
    const region = TestConstants.region;

const baseStackProps : BaseStackProps = {
  projectCode,
  appName,
  environment
};

    // create the S3 nested stack
    nestedStack = new S3Stack(stack, 'S3Stack', {
      ...baseStackProps
    });
  });
  test(" Content Resources Stack", () => {
    // testing is performed against cloudformation template
    const template = Template.fromStack(nestedStack);

    //testing description
    template.hasResourceProperties("AWS::S3::Bucket",{
      BucketName: "dev-s3-ew1-c81d-als-test-content-resources",
    });   
  });
});
