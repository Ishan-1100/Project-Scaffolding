/*
 * Filename: env-kms-stack.test
 * Created Date: Tuesday, Jan 22nd 2023, 11:12:59 pm
 * Author: ALS System Team
 *
 * Copyright (c) 2020 Airbus
 */

/**
 * Performs assertion test on kms substack
 **/
 import * as cdk from "aws-cdk-lib";
 import { NestedStack } from "aws-cdk-lib";
 import { EnvKmsStack } from "../lib/sub-stacks/env-kms-stack";
 import { KmsStackProps } from "../lib/interface/env-kms-interface";
 import { Constants } from "../lib/constants";
 import { Template } from "aws-cdk-lib/assertions";
 import * as kms from "aws-cdk-lib/aws-kms";
 import {getResourceName} from '../../shared/utils/utils'; 
 import {TestConstants} from './testConstants';
 
 let process : {
     env: {
       [key: string]: string
     }
   }
 
 describe("EnvKmsStack", () => {
   let app: cdk.App;
   app = new cdk.App();
   let stack: cdk.Stack;
   let nestedStack: NestedStack;
 
 
   const projectCode = TestConstants.projectCode;
   const appName = TestConstants.appName;
   const environment = TestConstants.environment;
   const region = TestConstants.region;
   const kmsKeyName = getResourceName("kms",region,environment,projectCode,appName); 
   let description = Constants.KMS_KEY_DESCRIPTION;
   let alias = kmsKeyName;
 
   //props of kms-stack.ts
   const kmsStackProps: KmsStackProps = {
     description: description,
     projectCode: projectCode,
     appName: appName,
     environment: environment
 };
 
 
   beforeEach(() => {
     app = new cdk.App();
     stack = new cdk.Stack(app, "TestStack", {});
     nestedStack = new EnvKmsStack(stack, "EnvKmsStack", kmsStackProps);
   });
 
   // testcases 
   test(" KMS TEST", () => {
     const kmsKey = new kms.Key(nestedStack, "KMSKey-test", {
       enableKeyRotation: true,
       alias: kmsKeyName,
       description: kmsStackProps.description,
     });
     // testing is performed against cloudformation template
     //referring template of Default KMS stack
     const template = Template.fromStack(nestedStack);
 
     //testing description
     template.hasResourceProperties("AWS::KMS::Key", {
       //it tests Description of the key
       Description: "CMK KMS Key",
     });
 
     //testing alias
     template.hasResourceProperties("AWS::KMS::Alias", {
       //it tests AliasName for the key
       AliasName: "alias/dev-kms-ew1-c81d-als-test",
     });
 
   });
 });
