/*
 * Filename: lambda.test
 * Created Date: Tuesday, Jan 22nd 2023, 11:12:59 pm
 * Author: ALS System Team
 *
 * Copyright (c) 2020 Airbus
 */

/**
 * Performs assertion test on Security group substack
 **/
import { BaseStackProps } from '../lib/interface/base-interface';
import { Template } from 'aws-cdk-lib/assertions';
import { LambdaSgStack } from '../lib/sub-stacks/lambda-sg-stack'; 
import { NestedStack, Stack, Fn, App} from 'aws-cdk-lib';
import { SecurityGroup, Vpc } from 'aws-cdk-lib/aws-ec2';
import { getResourceName } from '../../shared/utils/utils';
import {TestConstants} from './testConstants';

describe('lambda-sg-stack', () =>{
    let app= new App();
    let stack: Stack;
    let nestedStack: NestedStack;
    const projectCode = TestConstants.projectCode;
    const appName = TestConstants.appName;
    const environment = TestConstants.environment;
    const region = TestConstants.region;
    const opPrefix = `${projectCode}-${appName}`;

    beforeEach(() => {
        stack = new Stack(app, 'EnvDependenciesStack');
        const baseStackProps : BaseStackProps = {
          projectCode,
            appName,
            environment
          };       
          nestedStack = new LambdaSgStack(stack, 'LambdaSgStack', baseStackProps);
    })

    test("Testing lambda-SG", () => {  
        const networkingVpc = Vpc.fromVpcAttributes(nestedStack, 'NetworkingVpc', {
            availabilityZones: ['eu-west-1a', 'eu-west-1b'],
            publicSubnetIds: [
              Fn.importValue(`${opPrefix}-subnetAza`),
              Fn.importValue(`${opPrefix}-subnetAzb`)
            ],
            vpcId: Fn.importValue(`${opPrefix}-vpcId`),
          });

        const securityGroupName = getResourceName("sg",region,environment,projectCode,appName)
        const sg = new SecurityGroup(nestedStack, "security group ", 
        {vpc : networkingVpc, 
         allowAllOutbound: false,
         securityGroupName: securityGroupName
        });

        const template = Template.fromStack(nestedStack);

        template.hasResourceProperties("AWS::EC2::SecurityGroup",{
            GroupDescription: "EnvDependenciesStack/LambdaSgStack/LamabdaSG",
            GroupName: "dev-sg-ew1-c81d-als-test",
        } )
    })
}
)