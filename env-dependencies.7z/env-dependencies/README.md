## Environment Dependencies Stack

## Purpose 
The purpose of the document is to define the environment dependencies stack to be referred by projects. This stack needs to be deployed once the account config stack is deployed for the project.

## Overview
Stacks are implemented in nested form, stack named EnvDependenciesStack will create nested stacks for different AWS Services KMS key creation, S3 creation for hosting content resources, Security group creation and cognito userpool.
This further will be used to create Lambda@edge stack which will use the Cognito UserPool for authentication.

Code is available in following Github Repo : https://github.airbus.corp/airline-support-platform/project-scaffolding.git.

## Below is the description of stacks created in this project repository 

### EnvDependenciesStack:  
It instantiates the nested stacks and creates them as resources on cloudformation on AWS console.

### LambdaEdgeStack:
It creates the lambda edge apps using the cognito userpool authentication.

### Substacks
1.	EnvKmsStack: 	Creates environment specific KMS keys as required by the project.
2.	CognitoStack: 	Creates a cognito userpool which will be used as an authentication method by the lambda edge apps.
3.	LambdaSgStack: 	Creates the security group which will be utilized in further stacks.
4.	S3Stack: 		Creates an S3 bucket which will be used in later stacks to host frontend content resources.
5.	RDSStack:		Creates an RDS Aurora serverless stack
6.	Backupstack:	Creates AWS Backup plan for backing up EC2,RDS and S3 at regular intervals.

This cdk app project repository contains folders viz bin, lib, edge-deployer, lambda@edge and shared :

•	bin: 		cdk app for Account Config Stack is initiated.

•	lib: 		This folder contains the project Stack account config definition.
		Lib consists of sub-folders: sub-stacks and interface.
		
	•	Sub-stacks:	All the sub stacks are defined within individual files in this folder.

	•	Interface: 	This folder consists of individual files defining interfaces for each sub stack.

• 	edge-deployer: It contains the lambda code which to be deployed during lambda edge apps creation.
	
• 	lambda@edge: It contains folders specific to lambda edge apps and each folder generates it's own configuration.json to be used during app creation.
•	package.json: The package.json file is used to manage the npm packages that will be added as layers. Currently two packages related to log and event publishing are provided.

# Utilizing this environment dependency stack in projects:

Based on the requirement, a project can include the required sub stacks within the project.

For using a specific sub stack, changes are required in the respective interface file.

Predefined sets on inputs like aspire code (project code), project name (app name), environment are to be defined in the cdk.json file as context variables.

These can also be passed with -c option of the cdk deploy command, e.g

```sh
cdk deploy -c environment=dev -c projectCode=c81d -c appName=als-demo
```
While creating the Jenkinsfile for this deployment, below should be used for deploying stacks : 
cdk deploy --all --outputs-file ./env-output.json 

If any failure is seen for the deployment, all stacks should be destroyed explicitly using the below :
cdk destroy all