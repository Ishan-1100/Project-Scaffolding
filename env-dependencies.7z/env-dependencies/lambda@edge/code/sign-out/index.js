"use strict";
// Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const querystring_1 = require("querystring");
const shared_1 = require("../shared/shared");
const { clientId, oauthScopes, cognitoAuthDomain, cookieSettings, cloudFrontHeaders, redirectPathSignOut } = shared_1.getConfig();
exports.handler = async (event) => {
    const request = event.Records[0].cf.request;
    const domainName = request.headers['host'][0].value;
    const { idToken, accessToken, refreshToken } = shared_1.extractAndParseCookies(request.headers, clientId);
    if (!idToken) {
        return {
            status: '307',
            statusDescription: 'Temporary Redirect',
            headers: {
                'location': [{
                        key: 'location',
                        value: `https://${domainName}`,
                    }],
            }
        };
    }
    let tokens = { id_token: idToken, access_token: accessToken, refresh_token: refreshToken };
    const qs = {
        logout_uri: `https://${domainName}${redirectPathSignOut}`,
        client_id: clientId,
    };
    return {
        status: '307',
        statusDescription: 'Temporary Redirect',
        headers: {
            'location': [{
                    key: 'location',
                    value: `https://${cognitoAuthDomain}/logout?${querystring_1.stringify(qs)}`,
                }],
            'set-cookie': shared_1.getCookieHeaders({
                clientId, oauthScopes, tokens, domainName, explicitCookieSettings: cookieSettings, expireAllTokens: true
            }),
            ...cloudFrontHeaders,
        }
    };
};
