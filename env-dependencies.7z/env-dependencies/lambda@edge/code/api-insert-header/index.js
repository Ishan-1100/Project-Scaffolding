"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const shared_1 = require("../shared/shared");
const { clientId } = shared_1.getConfig();
exports.handler = async (event) => {
    const request = event.Records[0].cf.request;
    try {
        const { tokenUserName, idToken } = shared_1.extractAndParseCookies(request.headers, clientId);
        if (!tokenUserName || !idToken) {
            console.log('error');
            throw new Error('No valid credentials present in cookies');
        }
        request.headers['authorization'] = [{ key: 'authorization', value: idToken }];
        // Return the request unaltered to allow access to the resource:
        return request;
    }
    catch (err) {
        return request;
    }
};
