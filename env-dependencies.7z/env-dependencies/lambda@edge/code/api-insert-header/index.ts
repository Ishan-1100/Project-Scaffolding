
import { CloudFrontRequestHandler } from 'aws-lambda';
import { getConfig, extractAndParseCookies } from '../shared/shared';

const { clientId } = getConfig();


export const handler: CloudFrontRequestHandler = async (event) => {
    const request = event.Records[0].cf.request;

    try {
        const { tokenUserName, idToken } = extractAndParseCookies(request.headers, clientId);
        if (!tokenUserName || !idToken) {
            console.log('error');
            throw new Error('No valid credentials present in cookies');
        }
        request.headers['authorization'] = [{ key: 'authorization', value: idToken }];

        // Return the request unaltered to allow access to the resource:
        return request;

    } catch (err) {
        return request;
    }
}
