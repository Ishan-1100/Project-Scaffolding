"use strict";
// Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const fs_1 = require("fs");
const shared_1 = require("../shared/shared");
const configuredHeaders = getConfiguredHeaders();
exports.handler = async (event) => {
    const resp = event.Records[0].cf.response;
    Object.assign(resp.headers, configuredHeaders);
    return resp;
};
function getConfiguredHeaders() {
    const headers = JSON.parse(fs_1.readFileSync(`${__dirname}/configuration.json`).toString('utf8'));
    return shared_1.asCloudFrontHeaders(headers);
}
