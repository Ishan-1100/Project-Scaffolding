"use strict";
// Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const querystring_1 = require("querystring");
const shared_1 = require("../shared/shared");
const { clientId, oauthScopes, cognitoAuthDomain, redirectPathSignIn, cookieSettings, cloudFrontHeaders } = shared_1.getConfig();
exports.handler = async (event) => {
    const request = event.Records[0].cf.request;
    const domainName = request.headers['host'][0].value;
    let redirectedFromUri = `https://${domainName}`;
    try {
        const { code, pkce, requestedUri } = validateQueryStringAndCookies(request);
        redirectedFromUri += requestedUri;
        const body = querystring_1.stringify({
            grant_type: 'authorization_code',
            client_id: clientId,
            redirect_uri: `https://${domainName}${redirectPathSignIn}`,
            code,
            code_verifier: pkce
        });
        const headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
        const res = await shared_1.httpPostWithRetry(`https://${cognitoAuthDomain}/oauth2/token`, body, { headers });
        return {
            status: '307',
            statusDescription: 'Temporary Redirect',
            headers: {
                'location': [{
                        key: 'location',
                        value: redirectedFromUri,
                    }],
                'set-cookie': shared_1.getCookieHeaders({
                    clientId, oauthScopes, tokens: res.data, domainName, explicitCookieSettings: cookieSettings
                }),
                ...cloudFrontHeaders,
            }
        };
    }
    catch (err) {
        return {
            body: shared_1.createErrorHtml('Bad Request', err.toString(), redirectedFromUri),
            status: '400',
            headers: {
                ...cloudFrontHeaders,
                'content-type': [{
                        key: 'Content-Type',
                        value: 'text/html; charset=UTF-8',
                    }]
            }
        };
    }
};
function validateQueryStringAndCookies(request) {
    const { code, state, error: cognitoError, error_description } = querystring_1.parse(request.querystring);
    if (cognitoError) {
        throw new Error(`[Cognito] ${cognitoError}: ${error_description}`);
    }
    if (!code || !state || typeof code !== 'string' || typeof state !== 'string') {
        throw new Error(['Invalid query string. Your query string does not include parameters "state" and "code".',
            'This can happen if your authentication attempt did not originate from this site - this is not allowed'].join(' '));
    }
    let parsedState;
    try {
        parsedState = JSON.parse(Buffer.from(shared_1.urlSafe.parse(state), 'base64').toString());
    }
    catch {
        throw new Error('Invalid query string. Your query string does not include a valid "state" parameter');
    }
    if (!parsedState.requestedUri || !parsedState.nonce) {
        throw new Error('Invalid query string. Your query string does not include a valid "state" parameter');
    }
    const { nonce: originalNonce, pkce } = shared_1.extractAndParseCookies(request.headers, clientId);
    if (!parsedState.nonce || !originalNonce || parsedState.nonce !== originalNonce) {
        if (!originalNonce) {
            throw new Error('Your browser didn\'t send the nonce cookie along, but it is required for security (prevent CSRF).');
        }
        throw new Error('Nonce mismatch. This can happen if you start multiple authentication attempts in parallel (e.g. in separate tabs)');
    }
    return { code, pkce, requestedUri: parsedState.requestedUri || '' };
}
