const path = require('path');
const TerserPlugin = require('terser-webpack-plugin');

module.exports = {
  mode: 'production',
  target: 'node',
  node: {
    __dirname: false
  },
  entry: {
    'code/parse-auth/bundle': path.resolve(__dirname, './code/parse-auth/index.ts'),
    'code/check-auth/bundle': path.resolve(__dirname, './code/check-auth/index.ts'),
    'code/refresh-auth/bundle': path.resolve(__dirname, './code/refresh-auth/index.ts'),
    'code/http-headers/bundle': path.resolve(__dirname, './code/http-headers/index.ts'),
    'code/sign-out/bundle': path.resolve(__dirname, './code/sign-out/index.ts'),
    'code/api-insert-header/bundle': path.resolve(__dirname, './code/api-insert-header/index.ts'),
  },
  module: {
    rules: [
      {
        test: /\.ts$/,
        use: 'ts-loader',
        exclude: /node_modules/
      }
    ]
  },
  resolve: {
    extensions: [ '.ts', '.js' ]
  },
  output: {
    path: path.resolve(__dirname),
    filename: '[name].js',
    libraryTarget: 'commonjs',
  },
  externals: [
    /^aws-sdk/ // Don't include the aws-sdk in bundles as it is already present in the Lambda runtime
  ],
  performance: {
    hints: 'error',
    maxAssetSize: 1048576, // Max size of deployment bundle in Lambda@Edge Viewer Request
    maxEntrypointSize: 1048576, // Max size of deployment bundle in Lambda@Edge Viewer Request
  },
  optimization: {
    // minimize: false
    minimizer: [new TerserPlugin({
      parallel: true,
      extractComments: true,
    })],
  },
}
