import * as cdk from "aws-cdk-lib";
 import { NestedStack } from "aws-cdk-lib";
  import { Template } from "aws-cdk-lib/assertions";
   import { ServicesStack } from "../lib/substack/services-stack";
   describe("ServiceStsck", () => {
     let app: cdk.App; 
     app = new cdk.App(); 
     let stack: cdk.Stack; 
     let nestedStack: NestedStack; 
     
     
     beforeEach(() => {
        stack = new cdk.Stack(app, "TestStack", {});
        nestedStack = new ServicesStack(stack, "ServiceStach", {}); }); 
        test("service stack", () => 
        { const template = Template.fromStack(nestedStack); 
            template.hasResourceProperties("AWS::SecretsManager::Secret", 
    { Name: 'name-', }) }); });