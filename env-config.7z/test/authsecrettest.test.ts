import * as cdk from "aws-cdk-lib";
 import { NestedStack } from "aws-cdk-lib";
  import { Template } from "aws-cdk-lib/assertions";
   import { AuthHeaderSecretKeyStack } from "../lib/substack/auth-header-key-stack";
   describe("AuthHeaderSecretKeyStack", () => {
     let app: cdk.App; 
     app = new cdk.App(); 
     let stack: cdk.Stack; 
     let nestedStack: NestedStack; 
     
     
     beforeEach(() => {
        stack = new cdk.Stack(app, "TestStack", {}); 
        nestedStack = new AuthHeaderSecretKeyStack(stack, "AuthHeaderSecretKeyStack", {}); }); 
        test("authsecrettest", () => 
        { const template = Template.fromStack(nestedStack); 
            template.hasResourceProperties("AWS::SecretsManager::Secret", 
    { Name: 'name-', }) }); });