#!/usr/bin/env node
/*
* Filename: env-config.ts
* Path: 
* Created Date: Tuesday, March 26th 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/

/**
* Performs some checks and instantiation of the nested stacks
**/
import * as cdk from 'aws-cdk-lib';
import {Construct} from 'constructs';
import {AuthHeaderSecretStackProps} from './interface/auth-header-interface';
import { EnvConfigStackProps } from './interface/env-config-interface';
import { BaseStackProps } from './interface/base-interface';
import { AuthHeaderSecretKeyStack } from './substack/auth-header-key-stack';
import { getAccConfigResourceName, getResourceName } from '../../shared/utils/utils';
import { ServicesStack } from './substack/services-stack';
import { Fn, Stack } from 'aws-cdk-lib';
import { Key } from 'aws-cdk-lib/aws-kms';
import { Constants } from './constants';



/* Account Configuration Project Stack definition */
export class EnvConfigStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: EnvConfigStackProps) {
    super(scope, id, props);
    const {projectCode,appName,environment,subEnvironment} = props;  
    const region = Stack.of(this).region;

    /* Basic Stack properties */
    const baseStackProps : BaseStackProps = {
      projectCode,
      appName,
      environment,
      subEnvironment
    };

    const envKmsKeyName = getResourceName("kms",region,environment,projectCode,appName);
    const envKmsKeyArn = Fn.importValue(`${envKmsKeyName}-arn`);
    const kmsKey = Key.fromKeyArn(this,"getEnvKmsKey",envKmsKeyArn);

    
    const authHeaderSecretStackProps : AuthHeaderSecretStackProps = {
      ...baseStackProps,
      secretName: getAccConfigResourceName("secretManager", region, projectCode, appName, "header-secret"),
      secretDescription:"Secret manager for Header Keys",
      encryptionKey:kmsKey,
      removalPolicy:Constants.SECRET_MANAGER_REMOVAL_POLICY
    }
    
    const authSecretStack = new AuthHeaderSecretKeyStack(this,"authSecretStack",authHeaderSecretStackProps);

    //service stack
    const servicesStack = new  ServicesStack(this,"SharedServicesStack",{});
  }
}
