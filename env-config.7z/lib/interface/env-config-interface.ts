import { StackProps } from "aws-cdk-lib";

export interface EnvConfigStackProps extends StackProps {
    projectCode:string;
    appName:string;
    environment:string;
    subEnvironment?:string;
}
