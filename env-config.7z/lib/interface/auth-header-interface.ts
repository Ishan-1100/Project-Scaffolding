/**
* Interface for importing values into auth-header-key-stack.ts file
**/

import { RemovalPolicy,Fn } from "aws-cdk-lib";
import { IKey } from "aws-cdk-lib/aws-kms";
import { BaseStackProps } from "./base-interface";

const ResourceArnOutput = Fn.importValue('dev-kms-ew1-c81d-als-arn');
export interface AuthHeaderSecretStackProps extends BaseStackProps {
    
    secretName:string;
    secretDescription:string;
    encryptionKey:IKey;
    removalPolicy:RemovalPolicy
}