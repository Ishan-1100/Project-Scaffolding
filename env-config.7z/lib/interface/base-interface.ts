
import { NestedStackProps } from "aws-cdk-lib"
export interface BaseStackProps extends NestedStackProps {
    projectCode:string;
    appName:string;
    environment:string;
    subEnvironment?:string;
}
