import { RemovalPolicy } from "aws-cdk-lib";

export class Constants{
    static readonly SECRET_MANAGER_REMOVAL_POLICY = RemovalPolicy.DESTROY;
}