/*
* Filename: services-stack.ts
* Path: 
* Created Date: Tuesday, March 25th 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/
import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import * as waf from 'aws-cdk-lib/aws-wafv2';
import { NestedStackProps } from 'aws-cdk-lib/core';
import {CfnWebACL, CfnWebACLAssociation } from 'aws-cdk-lib/aws-wafregional';
import { getAccConfigResourceName } from '../../../shared/utils/utils';

export interface ServicesStackProps extends NestedStackProps {
  projectCode: string,
  accountAliasNumber: string,
  stage: string,
  nameSuffix: string,
  createRestApi?: boolean,
  createGraphqlApi?: boolean,
  schemaAsset?: string
}

// AWS WAF REST API
//To associate an AWS WAF regional Web ACL with an API Gateway API stage using the API Gateway console
export class ServicesStack extends cdk.NestedStack {
  public readonly restApi: apigateway.RestApi;
  public readonly webAcl: waf.CfnWebACL;
  

  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // Create a WAFv2 web ACL
    const webACL = new waf.CfnWebACL(this, 'WebACL', {
      name: getAccConfigResourceName("webACL","eu-west-1","dev1","c81d"),//name: 'APIGatewayWebACL',
      description:"webACL to apply on api gateway",
      defaultAction: { block: {} },
      scope: 'REGIONAL',
      visibilityConfig: {
        cloudWatchMetricsEnabled: true,
        metricName: 'WebACL',
        sampledRequestsEnabled: true
      },
    });

    // Create a WAFv2 rule group
    const ruleGlroup = new waf.CfnRuleGroup(this, 'RuleGroup', {
      capacity: 100,
      scope: 'REGIONAL',
      visibilityConfig: {
        cloudWatchMetricsEnabled: true,
        metricName: 'RuleGroup',
        sampledRequestsEnabled: true
      },
      name: 'APIGatewayRuleGroup',
      rules: [
        {
          action: { block: {} },
          name: 'BlockRequests',
          priority: 0,
          statement: {
            byteMatchStatement: {
              fieldToMatch: {
                singleHeader: {
                  Name: "header name" //**modify here */
                }
              },
              positionalConstraint: 'EXACTLY',
              //searchString: secret.toString(), //****is secret from headerauthstack required */
              textTransformations: [
                {
                  type: 'NONE',
                  priority: 0
                }
              ]
            }
          },
          visibilityConfig: {
            cloudWatchMetricsEnabled: true,
            sampledRequestsEnabled: true,
            metricName: 'BlockRequests'
          }
        }
      ]
    });

    // Create an API Gateway REST API
    const api = new apigateway.RestApi(this, 'MyAPI', {
      restApiName: 'MyAPI',
      deployOptions: {
        metricsEnabled: true,
        loggingLevel: apigateway.MethodLoggingLevel.INFO,
        dataTraceEnabled: true
      }
    });

    // Add a resource to the API Gateway
    const resource = api.root.addResource('myresource');

    // Add a method to the resource
    const method = resource.addMethod('GET');

    // Add a WAFv2 WebACLAssociation to the method
    //link to fix it
    //https://gist.github.com/statik/f1ac9d6227d98d30c7a7cec0c83f4e64
// const wafAssociation = new CfnWebACLAssociation(this, 'WafAssociation', {
//   resourceArn: method.methodArn,
//   webAclArn: webACL.attrArn,
  
// });
    // Add a WAFv2 RuleGroupReferenceStatement to the method
    const wafStatement = {
      name: 'WAFStatement',
      priority: 0,
      statement: {
        ruleGroupReferenceStatement: {
          arn: ruleGlroup.attrArn,
          excludedRules: []
        }
      },
      visibilityConfig: {
        cloudWatchMetricsEnabled: true,
        metricName: 'WAFStatement',
        sampledRequestsEnabled: true
      }
    };

    // Add the WAFv2 RuleGroupReferenceStatement to the method's methodResponses and integrationResponses
    /*
    const wafIntegration = method.addIntegration({
      type: apigateway.IntegrationType.HTTP_PROXY,
      uri: 'https://www.example.com',
      integrationHttpMethod: 'GET',
      options: {
        integrationResponses: [
          {
            statusCode: '200',
            responseTemplates
          }
        ]
      }
    }
    )*/
    
  }
}

/*
export class WafStack extends cdk.Stack {
    constructor(scope: Construct, id: string) {
        super(scope, id);
 
        // const CustomHeader = new cdk.CfnParameter(this, "CustomHeader", {
        //     type: "String",
        //     default: "x-key"
        // });
 
        //Web ACL
        const APIGatewayWebACL = new CfnWebACL(this, "APIGatewayWebACL", {
            name: "demo-api-gateway-webacl",
            description: "This is WebACL for Auth APi Gateway",
            scope: "REGIONAL",
            Action: { block: {} },
            visibilityConfig: {
                metricName: "demo-APIWebACL",
                cloudWatchMetricsEnabled: true,
                sampledRequestsEnabled: true
            },
            rules: [

                {
                    name: "demo-rateLimitRule",
                    priority: 20,
                    action: { block: {} },
                    visibilityConfig: {
                        metricName: "demo-rateLimitRule",
                        cloudWatchMetricsEnabled: true,
                        sampledRequestsEnabled: false
                    },
                    statement: {
                        rateBasedStatement: {
                            aggregateKeyType: "IP",
                            limit: 100
                        }
                    }
                },
                {
                    name: `demo-api-auth-gateway-geolocation-rule`,
                    priority: 30,
                    action: { allow: {} },
                    visibilityConfig: {
                        metricName: `demo-AuthAPIGeoLocationUS`,
                        cloudWatchMetricsEnabled: true,
                        sampledRequestsEnabled: false
                    },
                    statement: {
                        geoMatchStatement: {
                            countryCodes: ['US']
                        }
                    }
                },
                {
                    name: `demo-api-auth-gateway-sqli-rule`,
                    priority: 40,
                    action: { block: {} },
                    visibilityConfig: {
                        metricName: `demo-APIAuthGatewaySqliRule`,
                        cloudWatchMetricsEnabled: true,
                        sampledRequestsEnabled: false
                    },
                    statement: {
                        orStatement: {
                            statements: [{
                                sqliMatchStatement: {
                                    fieldToMatch: {
                                        allQueryArguments: {}
                                    },
                                   textTransformations: [{
                                        priority: 1,
                                        type: "URL_DECODE"
                                    },
                                    {
                                        priority: 2,
                                        type: "HTML_ENTITY_DECODE"
                                    }]
                                }
                            },
                            {
                                sqliMatchStatement: {
                                    fieldToMatch: {
                                        body: {}
                                    },
                                    textTransformations: [{
                                        priority: 1,
                                        type: "URL_DECODE"
                                    },
                                    {
                                        priority: 2,
                                        type: "HTML_ENTITY_DECODE"
                                    }]
                                }
                            },
                            {
                                sqliMatchStatement: {
                                    fieldToMatch: {
                                        uriPath: {}
                                    },
                                    textTransformations: [{
                                        priority: 1,
                                        type: "URL_DECODE"
                                    }]
                                }
                            }]
                        }
                    }
                },
                {
                    name: `demo-detect-xss`,
                    priority: 60,
                    action: { block: {} },
                    visibilityConfig: {
                        metricName: `demo-detect-xss`,
                        cloudWatchMetricsEnabled: true,
                        sampledRequestsEnabled: false
                    },
                    statement: {
                        orStatement: {
                            statements: [
                                {
                                    xssMatchStatement: {
                                        fieldToMatch: {
                                            uriPath: {}
                                        },
                                        textTransformations: [{
                                            priority: 1,
                                            type: "URL_DECODE"
                                        },
                                        {
                                            priority: 2,
                                            type: "HTML_ENTITY_DECODE"
                                        }]
                                    }
                                },
                                {
                                    xssMatchStatement: {
                                        fieldToMatch: {
                                            allQueryArguments: {}
                                        },
                                        textTransformations: [{
                                            priority: 1,
                                            type: "URL_DECODE"
                                        },
                                        {
                                            priority: 2,
                                            type: "HTML_ENTITY_DECODE"
                                        }]
                                    }
                                },
                               
                            ]
                        }
                    }
                }
            ]
        });
 
        // Web ACL Association
        // const APIGatewayWebACLAssociation = 
        new CfnWebACLAssociation(this, "APIGatewayWebACLAssociation", {
            webAclArn: APIGatewayWebACL.attrArn,
            resourceArn: cdk.Fn.join("", ["arn:aws:apigateway:us-east-1::/restapis/", cdk.Fn.importValue("demorestapiid"), "/stages/prod", ])
        });
    }
}
 
*/


