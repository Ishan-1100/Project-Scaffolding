/*
* Filename: auth-header-key-stack.ts
* Path: 
* Created Date: Tuesday, March 25th 2023, 11:12:59 pm
* Author: ALS System Team 
* 
* Copyright (c) 2020 Airbus
*/
import { NestedStack,Fn } from 'aws-cdk-lib';
import { IKey } from 'aws-cdk-lib/aws-kms';
import * as kms from 'aws-cdk-lib/aws-kms';
import { Secret } from 'aws-cdk-lib/aws-secretsmanager';
import {Construct} from 'constructs';
import { AuthHeaderSecretStackProps } from '../interface/auth-header-interface';

export class AuthHeaderSecretKeyStack extends NestedStack {
  constructor(scope: Construct, id: string, props: AuthHeaderSecretStackProps) {
    super(scope, id, props);

    //encryption key used for secret
    
    // kmskey.keyname
    const myKeyImported = kms.Key.fromKeyArn(this, 'MyImportedKey', 'arn:aws:kms:eu-west-1:872768075493:key/01d8dded-a14f-47b1-8c25-c88566368f2f');     
    const {secretName,secretDescription,encryptionKey,removalPolicy} = props;
    // {encryptionKey} = ResourceArnOutput;
    const secret = new Secret(this, 'HeaderSecret', {
      secretName:secretName,
      description:secretDescription,
      encryptionKey:myKeyImported,
      generateSecretString: {
        passwordLength: 64,
        includeSpace: false,
        excludePunctuation: true,
        excludeNumbers: false,
      },
      removalPolicy
    });
  }
}


