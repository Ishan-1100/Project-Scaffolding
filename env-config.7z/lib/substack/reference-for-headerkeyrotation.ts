//some usefull imports
import * as cloudfront from 'aws-cdk-lib/aws-cloudfront';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as kms from 'aws-cdk-lib/aws-kms';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as wafv2 from 'aws-cdk-lib/aws-wafv2';
import * as secretManager from 'aws-cdk-lib/aws-secretsmanager';
import { Stack, StackProps, Duration, Fn } from 'aws-cdk-lib';
import {Construct} from 'constructs';
import * as path from 'path';

import { getLogsFactory } from "./logsConfig";
import { HEADER_NAME } from "./ContentHostingStack";

const logger = getLogsFactory().getLogger("pcp-wips.InterconnexionStack");


//interconnection interface 
export interface InterconnexionStackProps extends NestedStackProps {
    projectCode: string,
    stage: string,
    nameSuffix: string,
    encryptionKey: kms.IKey,
    cloudfront: cloudfront.IDistribution,
    webAcl: wafv2.CfnWebACL
    vpcId: string,
    subnetIds: string[]
  }


  //nested stack for interconnection starts here
  export class InterconnexionStack extends NestedStack {

    constructor(scope: Construct, id: string, props: InterconnexionStackProps) {
      super(scope, id, props);

      const stack = Stack.of(this);
    
      const regionShortned = stack.region.split("-").map(s => s[0]).join("");
      const secretNameRef = `${props.stage}-secret-${regionShortned}-${props.projectCode}-${props.nameSuffix}`;
      // Get deployed ecret into Secret manager
      const secretArn = Fn.importValue(`${secretNameRef}-arn`);
      const secret = secretManager.Secret.fromSecretCompleteArn(this, 'HeaderSecret', secretArn);
  
      const basicLambdaPolicy = iam.ManagedPolicy.fromManagedPolicyArn(this, 'BasicLambdaPolicy', 'arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole');
      const wafV2LambdaPolicy = new iam.PolicyStatement();
      wafV2LambdaPolicy.addActions('wafv2:GetWebAcl',
        'wafv2:UpdateWebAcl');
  
      wafV2LambdaPolicy.addResources(props.webAcl.attrArn);

      

    }

}