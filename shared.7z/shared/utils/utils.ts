type ServiceMap = {
    [key: string]: string;
}

//add more entries to this map as needed
const serviceToShortHandMap:ServiceMap = {
    "kms":"kms",
    "lambda":"lbd",
    "s3":"s3",
    "sg":"sg",
    "database":"db",
    "credentials":"creds",
    "backupPlan":"bp",
    "backupRule":"brul",
    "backupSelection":"bsel",
    "backupVault":"bvlt",
    "secretManager":"scrtmgr"
};

export function getShortenedRegion(region:string):string{
    return region.split("-").map(s => s[0]).join("");
}

/* Function to generate Resource Name for Account Config Stacks */
export function getAccConfigResourceName(service:string,region:string,projectCode:string,appName:string,suffix?:string){
    const serviceShortHand = serviceToShortHandMap[service];
    const regionShortned = getShortenedRegion(region);

    let accConfigResourceName = `${serviceShortHand}-${regionShortned}-${projectCode}-${appName}`;
    if(suffix){
        accConfigResourceName+=`-${suffix}`
    }
    return accConfigResourceName;
}

/* Function to generate Resource Name for Environment dependent Stacks */
export function getResourceName(service:string,region:string,environment:string,projectCode:string,appName:string,suffix?:string){
    const serviceShortHand = serviceToShortHandMap[service];
    const regionShortned = getShortenedRegion(region);
    let resourceName = `${environment}-${serviceShortHand}-${regionShortned}-${projectCode}-${appName}`;
    if(suffix){
        resourceName+=`-${suffix}`
    }
    return resourceName;
}