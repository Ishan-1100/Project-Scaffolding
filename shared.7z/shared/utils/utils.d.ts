export declare function getShortenedRegion(region: string): string;
export declare function getAccConfigResourceName(service: string, region: string, projectCode: string, appName: string, suffix?: string): string;
export declare function getResourceName(service: string, region: string, environment: string, projectCode: string, appName: string, suffix?: string): string;
                                                                        envirionment family