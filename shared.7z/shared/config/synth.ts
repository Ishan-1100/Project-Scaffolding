const deployRoleArn = 'arn:aws:iam::${AWS::AccountId}:role/role-${Qualifier}-deploy-role-${AWS::AccountId}-${AWS::Region}';
const fileAssetPublishingRoleArn = 'arn:aws:iam::${AWS::AccountId}:role/role-${Qualifier}-file-publishing-role-${AWS::AccountId}-${AWS::Region}';
const imageAssetPublishingRoleArn = 'arn:aws:iam::${AWS::AccountId}:role/role-${Qualifier}-image-publishing-role-${AWS::AccountId}-${AWS::Region}';
const cloudFormationExecutionRole = 'arn:${AWS::Partition}:iam::${AWS::AccountId}:role/role-${Qualifier}-cfn-exec-role-${AWS::AccountId}-${AWS::Region}';
const bootstrapStackVersionSsmParameter = '/cdk-bootstrap/${Qualifier}/version';

export const Synth = {
  deployRoleArn,
  fileAssetPublishingRoleArn,
  imageAssetPublishingRoleArn,
  cloudFormationExecutionRole,
  bootstrapStackVersionSsmParameter,
};