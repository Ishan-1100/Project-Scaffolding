module.exports = {
    collectCoverage: false,
    coverageReporters: ["lcov"],
    coverageDirectory: "test-coverage",
    coverageThreshold: {
     global: {
     branches: 70,
     functions: 70,
     lines: 70,
     statements: 70
     }
    },
    moduleNameMapper: {
        '\\.(css|less|scss)$': 'identity-obj-proxy',
        '@react-hook/(.*)': '<rootDir>/node_modules/@react-hook/resize-observer/dist/main/index.js'
    },
    setupFilesAfterEnv: [
        '@testing-library/jest-dom/extend-expect'
    ],
    testMatch: [
        '**/?(*.)(test|spec).ts?(x)'
    ],
    globals: {
        'ts-jest': {
            tsConfig: './tsconfig.json',
            diagnostics: false,
        },
    },
    testEnvironment: 'jsdom',
    preset: 'ts-jest',
}