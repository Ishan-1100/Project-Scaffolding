/*  
 *  @Description: E2E test example with cypress.
 *    Test if page has a <section> tag visible and has a <main> tag child. 
 */
describe('App spec.', () => {
    it('Page loads successfully', () => {
        cy.visit('http://localhost:3000'); // should be replaced by `baseUrl` in cypress config
        cy.get('section')
        .should('be.visible')
        .within(() => {
            cy.get('main')
                .should('be.visible');
        });
    });
});