import * as React from 'react';
import {render, screen} from '@testing-library/react';
import ExampleComponent from '../../../../components/example/ExampleComponent';

describe('ExampleComponent unit tests', () => {
    test('renders ExampleComponent component', () => {
        render(<ExampleComponent apiUrl={'https://baconipsum.com/api/?type=meat-and-filler'} />);
        const AirbusButtonPrimary = screen.getByTestId('airbus-button-primary');
        const HeadingLabel = screen.getByTestId('heading-label');
        expect(HeadingLabel.innerHTML).toEqual('Example Component');
        expect(AirbusButtonPrimary).toBeInTheDocument()
    });
});
