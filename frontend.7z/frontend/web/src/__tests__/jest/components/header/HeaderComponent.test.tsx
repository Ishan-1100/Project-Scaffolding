import * as React from 'react';
import {render, screen} from '@testing-library/react';
import HeaderComponent from '../../../../components/header/HeaderComponent';
import {UILink} from '../../../../types/global.types';
import "@testing-library/jest-dom";

import { BrowserRouter as Router } from 'react-router-dom';
const links: Array<UILink> = [
    {text: 'Index', path: '/'},
    {text: 'Item 1', path: '/items_1'},
    {text: 'Item 2', path: '/items_2'},
];

describe('ExampleComponent unit tests', () => {
    test('renders HeaderComponent component', () => {
        render(<Router><HeaderComponent links={links} /></Router>);
        const AirbusHeader = screen.getByTestId('airbus-header');
        expect(AirbusHeader).toBeInTheDocument();
    });
});
