/** Types defined in this file to be replaced by projects */

type ExampleComponentProps = {
    apiUrl?: string;
};

type ExampleComponentState = {
    apiUrl?: string;
    content: Array<string>;
};

export type {ExampleComponentState, ExampleComponentProps};
