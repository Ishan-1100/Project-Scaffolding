import React, {useState} from 'react';
import {Container, Card} from 'react-bootstrap';
import {Button} from '@airbus/components-react';
import {getData} from '../../services/services';
import {API} from '../../config/apiConfig';
import {heading} from '../../constants/constants';
import {
    ExampleComponentProps,
    ExampleComponentState,
} from './ExampleComponent.types';
import './ExampleComponent.scss';

const ExampleComponent: React.FC<ExampleComponentProps> = (
    props: ExampleComponentProps,
) => {
    // API and Local JSON URL configured. For Demo purpose only
    const api = `${API.baseUrl}${API.queryParams}` || `${API.localJSONUrl}`;
    const initialState: ExampleComponentState = {
        apiUrl: props.apiUrl || api,
        content: [],
    };
    const [state, setState] = useState(initialState);

    const getLoremIpsumAsync = () => {
        getData(state.apiUrl)
            .then((res) => {
                setState({
                    content: res.data.length > 0 ? res.data : state.content,
                    apiUrl: state.apiUrl,
                });
            })
            .catch((err) => {
                setState({
                    content: err.data,
                    apiUrl: state.apiUrl,
                });
            });
    };

    if (state.content.length < 1) {
        getLoremIpsumAsync();
    }

    return (
        <Container>
            <Card>
                <Card.Header>
                    <h2 className="text-center" data-testid={'heading-label'}>
                        {heading.label}
                    </h2>
                </Card.Header>
                <Card.Body>
                    <Card.Text>
                        {/* axios demo -----> */}
                        <Button
                            className="mb-4 mt-4"
                            data-testid={'airbus-button-primary'}
                            variant="primary"
                            onClick={getLoremIpsumAsync}>
                            Refresh content
                        </Button>
                        <>
                            {state.content.map(
                                (item: string, index: number) => (
                                    <span key={index}>{item}</span>
                                ),
                            )}
                        </>
                        {/* <------ */}
                    </Card.Text>
                </Card.Body>
            </Card>
        </Container>
    );
};

export default ExampleComponent;
export type {ExampleComponentProps};
