import React from 'react';
import {Navbar, Container, Nav} from 'react-bootstrap';
import {Link} from 'react-router-dom';
import {UILink} from '../../types/global.types';
import './Footer.scss';

type FooterProps = {
    links?: Array<UILink>;
};

const Footer: React.FC<FooterProps> = (props: FooterProps) => {
    return (
        <footer className="Footer">
            <Navbar className="Footer-navbar">
                <Container>
                    <Nav className="me-auto">
                        {props.links?.map((link: UILink) => (
                            <Link
                                key={link.path}
                                to={link.path}
                                className="Footer-link nav-link">
                                {link.text}
                            </Link>
                        ))}
                    </Nav>
                </Container>
            </Navbar>
        </footer>
    );
};

export default Footer;
