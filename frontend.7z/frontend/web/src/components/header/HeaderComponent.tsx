import React from 'react';
import {Link} from 'react-router-dom';
import {Header} from '@airbus/components-react';
import {UILink} from '../../types/global.types';
import './HeaderComponent.scss';

type HeaderProps = {
    links?: Array<UILink>;
};

const HeaderComponent: React.FC<HeaderProps> = (props: HeaderProps) => {
    return (
        <Header data-testid="airbus-header">
            {props.links?.map((link: UILink) => (
                <Link
                    to={link.path}
                    key={link.path}
                    className="Header-link nav-link">
                    {link.text}
                </Link>
            ))}
        </Header>
    );
};

export default HeaderComponent;
