/** Types defined in this file to be replaced by projects */
import React from 'react';

type UILink = {
    path: string;
    text: string;
};

type AppChildren = {
    link: UILink;
    path: string;
    component: React.FC;
};

export type {UILink, AppChildren};
