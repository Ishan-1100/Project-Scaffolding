// image
declare module '*.png';
declare module '*.svg';
declare module '*.jpeg';
declare module '*.jpg';
declare module '*.gif';
declare module '*.tiff';
declare module '*.psd';
declare module '*.pdf';

// video
declare module '*.mp4';
declare module '*.mkv';
declare module '*.mov';
declare module '*.wmv';
declare module '*.flv';
declare module '*.avi';
declare module '*.3gp';
