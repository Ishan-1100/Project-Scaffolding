/** API configuration defined in this file to be replaced by projects.
 *  New objects can be introduced for different API's */

export const API = {
    baseUrl: 'https://baconipsum.com/api/',
    queryParams: '?type=meat-and-filler',
    localJSONUrl: 'http://localhost:3000/mockData/initialLoad.json',
};
