import React from 'react';
import {Routes, Route} from 'react-router-dom';
import Footer from './components/footer/Footer';
import Header from './components/header/HeaderComponent';
import AppContainer from './containers/AppContainer';
import {UILink} from './types/global.types';
import './App.scss';

const App: React.FC = () => {
    const links: Array<UILink> = [
        {text: 'Index', path: '/'},
        {text: 'Item 1', path: '/items_1'},
        {text: 'Item 2', path: '/items_2'},
    ];
    return (
        <section className="App">
            <Header links={links} />
            <main className="App-main">
                <Routes>
                    <Route path="/" element={<AppContainer />}>
                        <Route index element={<AppContainer />} />
                        <Route path="items_1" element={<AppContainer />} />
                        <Route path="items_2" element={<AppContainer />} />
                    </Route>
                </Routes>
            </main>
            <Footer links={links} />
        </section>
    );
};

export default App;
