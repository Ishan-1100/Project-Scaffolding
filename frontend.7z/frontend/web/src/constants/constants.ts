/** Objects and their properties defined in this file to be replaced by projects */

export const heading = {
    label: 'Example Component',
};
