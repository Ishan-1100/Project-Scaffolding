import React from 'react';
import ExampleComponent from '../components/example/ExampleComponent';

const AppContainer: React.FC = () => {
    return <ExampleComponent />;
};

export default AppContainer;
