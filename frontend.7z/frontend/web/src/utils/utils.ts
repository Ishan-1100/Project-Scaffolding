// src/utils default file to add folder to git
const Utils: () => void = () => {
    // utils example function
};

export {Utils};
