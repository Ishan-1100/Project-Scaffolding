import axios from 'axios';

export function getData(url: string) {
    return axios
        .get(url)
        .then((res) => res)
        .catch((err) => err);
}
