import path from 'path';
import {Configuration, DefinePlugin} from 'webpack';
import HtmlWebpackPlugin from 'html-webpack-plugin';
import ForkTsCheckerWebpackPlugin from 'fork-ts-checker-webpack-plugin';
const WebpackAssetsManifest = require('webpack-assets-manifest');
import {} from 'webpack-dev-server';
const fs = require('fs');
const appDirectory = fs.realpathSync(process.cwd());
const resolveApp = relativePath => path.resolve(appDirectory, relativePath);
const homePage = require(resolveApp('package.json')).homepage;


const webpackConfig = (env): Configuration => ({
    mode: process.argv[2].includes('production')?'production':'development',
    entry: './src/index.tsx',
    ...(process.env.production || !process.env.development
        ? {}
        : {devtool: 'eval-source-map'}),

    resolve: {
        extensions: ['.ts', '.tsx', '.js'],
    },
    output: {
        path: path.join(__dirname, '/build'),
        filename: 'build.[chunkhash:16].js',
        chunkFilename: "[id].chunk.js",
        assetModuleFilename: 'assets/[name][ext][query]',
        publicPath: homePage,
        clean:true
    },
    module: {
        rules: [
            {
                test: /\.tsx?$/,
                loader: 'ts-loader',
                options: {
                    transpileOnly: true,
                },
                exclude: [/build/, /src\/__tests__/],
            },
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        cacheDirectory: true
                    }
                }
            },
            {
                test: /\.(png|svg|jpg|jpeg|gif|psd|pdf|tiff)$/i,
                type: 'asset/resource',
            },
            {
                test: /\.(3gp|mp4|mkv|mov|wmv|flv|avi)$/i,
                type: 'asset/resource',
            },
            {
                test: /\.s?css$/,
                use: ['style-loader', 'css-loader', 'sass-loader'],
            }
        ],
    },
    optimization:{
        // For Spliting Bundle into different files
        splitChunks: {
            cacheGroups: {
                commons: {
                    test: /[\\/]node_modules[\\/]/,
                    name: "vendors",
                    filename : "[name].[chunkhash:16].js",
                    chunks: "all"
                }
            }
        }
    },
    devServer: {
        port: 3000,
        open: true,
        historyApiFallback: true,
    },
    plugins: [
         // HtmlWebpackPlugin simplifies creation of HTML files to serve your webpack bundles
        new HtmlWebpackPlugin({
                template: './public/index.html',
        }),

        // DefinePlugin allows you to create global constants which can be configured at compile time
        new DefinePlugin({
            'process.env': process.env.production || !process.env.development,
        }),

        // WebpackAssetsManifest allows you to create asset-manifest.json
        new WebpackAssetsManifest({
            output: 'asset-manifest.json',
        }),
        
         // Speeds up TypeScript type checking and ESLint linting (by moving each to a separate process)
        new ForkTsCheckerWebpackPlugin({
            eslint: {
                files: './src/**/*.{ts,tsx,js,jsx}',
            },
        }),
    ],
});

export default webpackConfig;
